import type { CapacitorConfig } from '@capacitor/cli';

const config: CapacitorConfig = {
  appId: 'com.workbench.life',
  appName: '我的工作台',
  // 打包的静态资源目录（pnpm build:app 会生成）
  webDir: 'dist-app',

  android: {
    // 允许混合内容，兼容字体等外部资源
    allowMixedContent: false,
    // 背景色与主题一致，避免启动瞬间白屏
    backgroundColor: '#FBF8F5',
  },

  plugins: {
    SplashScreen: {
      // 启动图停留时间（毫秒）
      launchShowDuration: 600,
      backgroundColor: '#F97362',
      androidScaleType: 'CENTER_CROP',
      showSpinner: false,
      // 首屏渲染后自动隐藏
      launchAutoHide: true,
      splashFullScreen: true,
      splashImmersive: true,
    },
    StatusBar: {
      // 状态栏叠在页面之上，配合 CSS 安全区实现沉浸式
      // 注意：overlaysWebView 为 true 时 backgroundColor 不生效
      overlaysWebView: true,
      style: 'DARK',
    },
  },
};

export default config;
