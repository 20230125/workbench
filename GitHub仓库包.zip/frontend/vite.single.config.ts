import path from 'path'
import tailwindcss from '@tailwindcss/vite'
import react from '@vitejs/plugin-react-swc'
import { defineConfig } from 'vite'

// 单文件（IIFE）构建配置：产物可被 <script> 直接执行，file:// 双击即可打开
export default defineConfig({
  plugins: [react(), tailwindcss()],
  resolve: {
    alias: { '@': path.resolve(__dirname, './src') },
  },
  define: {
    'process.env.NODE_ENV': JSON.stringify('production'),
    'process.env': '{}',
    global: 'globalThis',
  },
  build: {
    lib: {
      entry: 'src/single-entry.tsx',
      formats: ['iife'],
      name: 'WorkbenchApp',
      fileName: () => 'app.js',
    },
    rollupOptions: {
      output: { inlineDynamicImports: true, assetFileNames: 'app.[ext]' },
    },
    cssCodeSplit: false,
    outDir: '.single-dist',
    emptyOutDir: true,
  },
})
