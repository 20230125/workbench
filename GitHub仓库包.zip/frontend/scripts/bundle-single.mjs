// 把 IIFE 产物（app.js + app.css）内联进单个 HTML，输出到项目根目录「工作台.html」
// 用法：pnpm build:single
//
// ⚠️ 关键点：String.prototype.replace 的「替换字符串」中 $&、$$、$' 等是特殊变量。
//    JS 压缩产物里天然含有 "$$typeof"、".replace(Et,"$&/")" 这类片段，
//    若直接把 js 当作替换串传入，会被 replace 就地改写（$$ → 掉成 $），
//    从而产生 "Invalid or unexpected token" / 正则错误。
//    因此所有替换一律使用 **函数返回值**，彻底绕开 $ 转义语义。
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const here = path.dirname(fileURLToPath(import.meta.url));
const root = path.resolve(here, '..');
const dist = path.resolve(root, '.single-dist');

const template = fs.readFileSync(path.join(root, 'index.html'), 'utf8');
const jsRaw = fs.readFileSync(path.join(dist, 'app.js'), 'utf8');
const css = fs.readFileSync(path.join(dist, 'app.css'), 'utf8');
const faviconPath = path.join(dist, 'favicon.svg');
const favicon = fs.existsSync(faviconPath) ? fs.readFileSync(faviconPath) : null;

// 1) 转义会提前终止 HTML 解析的序列
const js = jsRaw
  .replace(/<\/(script|body|html)/gi, (m, tag) => `<\\/${tag}`)
  .replace(/<!--/g, '<\\!--');

// 2) 模板处理：去掉外链，全部用函数式替换
let html = template;
html = html.replace(/<script[^>]*src="[^"]*"[^>]*><\/script>/g, () => '\u0000SCRIPT\u0000');
html = html.replace(/<link[^>]*stylesheet[^>]*>/g, () => '');
html = html.replace(/<link[^>]*preconnect[^>]*>/g, () => '');
html = html.replace(/<link[^>]*fonts\.googleapis[^>]*>/g, () => '');

if (favicon) {
  const b64 = favicon.toString('base64');
  html = html.replace(/<link rel="icon"[^>]*>/, () => {
    return `<link rel="icon" type="image/svg+xml" href="data:image/svg+xml;base64,${b64}" />`;
  });
}

html = html.replace('</head>', () => `<style>\n${css}\n</style>\n</head>`);
html = html.replace('\u0000SCRIPT\u0000', () => `<script>\n${js}\n</script>`);

// 3) 自检：内联后的脚本必须能被解析，且占位符不得残留
if (html.includes('\u0000SCRIPT\u0000')) {
  throw new Error('❌ 脚本占位符未被替换，检查 index.html 中 script 标签写法');
}
if (!html.includes(`<script>\n${js}\n</script>`)) {
  throw new Error('❌ 内联脚本与源文件不一致，疑似被 replace 的 $ 语义改写');
}

const out = path.resolve(root, '..', '工作台.html');
fs.writeFileSync(out, html, 'utf8');
console.log(
  `✅ 单文件已生成：${out}（${Math.round(html.length / 1024)} KB）` +
    `\n   脚本 ${Math.round(js.length / 1024)} KB / 样式 ${Math.round(css.length / 1024)} KB` +
    `\n   安全转义序列：${(jsRaw.match(/<\/(script|body|html)|<!--/gi) || []).length} 处`
);
