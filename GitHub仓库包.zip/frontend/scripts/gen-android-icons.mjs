// 生成安卓各密度启动图标（含自适应图标前景/背景）
// 用法：node scripts/gen-android-icons.mjs
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { execFileSync } from 'node:child_process';

const here = path.dirname(fileURLToPath(import.meta.url));
const frontend = path.resolve(here, '..');
const res = path.join(frontend, 'android', 'app', 'src', 'main', 'res');
const svg = path.join(frontend, 'public', 'icon.svg');

if (!fs.existsSync(res)) {
  console.error('❌ 未找到安卓工程，请先运行 npx cap add android');
  process.exit(1);
}

// 各密度传统图标尺寸
const DENSITIES = {
  mdpi: 48,
  hdpi: 72,
  xhdpi: 96,
  xxhdpi: 144,
  xxxhdpi: 192,
};

// 自适应图标前景：108dp 画布，安全区中心 72dp，图形需留边
const FOREGROUND = {
  mdpi: 108,
  hdpi: 162,
  xhdpi: 216,
  xxhdpi: 324,
  xxxhdpi: 432,
};

function convert(src, out, size, extra = []) {
  execFileSync('python3', [
    '-c',
    `
import cairosvg, sys
cairosvg.svg2png(url=r"${src}", write_to=r"${out}", output_width=${size}, output_height=${size})
`,
    ...extra,
  ]);
}

// 1) 生成传统方形图标
for (const [d, size] of Object.entries(DENSITIES)) {
  const dir = path.join(res, `mipmap-${d}`);
  fs.mkdirSync(dir, { recursive: true });
  for (const name of ['ic_launcher.png', 'ic_launcher_round.png']) {
    convert(svg, path.join(dir, name), size);
  }
  console.log(`✅ mipmap-${d} (${size}px)`);
}

// 2) 生成自适应图标前景（透明底，图形缩小到 66% 以留出安全边距）
const fgSvg = fs.readFileSync(svg, 'utf8')
  // 移除满幅背景矩形，只保留图形
  .replace(/<rect width="512" height="512" fill="url\(#bg\)"\/>/, '')
  .replace(/<rect width="512" height="250" fill="#FFFFFF" opacity="0.10"\/>/, '')
  // 把内容等比缩小到中心区域
  .replace(
    /(<\/defs>)/,
    `$1\n  <g transform="translate(256 256) scale(0.66) translate(-256 -256)">`
  )
  .replace(/<\/svg>/, '</g>\n</svg>');

const fgTmp = path.join(frontend, '.icon-foreground.svg');
fs.writeFileSync(fgTmp, fgSvg, 'utf8');

for (const [d, size] of Object.entries(FOREGROUND)) {
  const dir = path.join(res, `mipmap-${d}`);
  convert(fgTmp, path.join(dir, 'ic_launcher_foreground.png'), size);
  console.log(`✅ 自适应前景 mipmap-${d} (${size}px)`);
}
fs.unlinkSync(fgTmp);

// 3) 自适应图标背景色
const valuesDir = path.join(res, 'values');
fs.mkdirSync(valuesDir, { recursive: true });
const bgXml = `<?xml version="1.0" encoding="utf-8"?>
<resources>
    <color name="ic_launcher_background">#F97362</color>
</resources>
`;
fs.writeFileSync(path.join(valuesDir, 'ic_launcher_background.xml'), bgXml, 'utf8');
console.log('✅ 自适应背景色 #F97362');

// 4) 自适应图标描述（anydpi-v26）
const anydpi = path.join(res, 'mipmap-anydpi-v26');
fs.mkdirSync(anydpi, { recursive: true });
if (!fs.existsSync(path.join(anydpi, 'ic_launcher.xml'))) {
  const launcherXml = `<?xml version="1.0" encoding="utf-8"?>
<adaptive-icon xmlns:android="http://schemas.android.com/apk/res/android">
    <background android:drawable="@color/ic_launcher_background"/>
    <foreground android:drawable="@mipmap/ic_launcher_foreground"/>
    <monochrome android:drawable="@mipmap/ic_launcher_foreground"/>
</adaptive-icon>
`;
  fs.writeFileSync(path.join(anydpi, 'ic_launcher.xml'), launcherXml, 'utf8');
  fs.writeFileSync(path.join(anydpi, 'ic_launcher_round.xml'), launcherXml, 'utf8');
  console.log('✅ 自适应图标 XML');
}

console.log('\n🎉 安卓图标生成完成');
