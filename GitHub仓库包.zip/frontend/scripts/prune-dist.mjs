// 构建后清理：dist-web 输出目录不在 Vite 工程内，Vite 不会自动清空，
// 导致每次构建都堆积旧的 index-xxxx.js/css。这里只保留 index.html 实际引用的资源。
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const here = path.dirname(fileURLToPath(import.meta.url));
const dist = path.resolve(here, '..', '..', 'dist-web');
const assetsDir = path.join(dist, 'assets');

if (!fs.existsSync(dist) || !fs.existsSync(assetsDir)) {
  process.exit(0);
}

const html = fs.readFileSync(path.join(dist, 'index.html'), 'utf8');
const used = new Set(
  (html.match(/assets\/[A-Za-z0-9._-]+/g) || []).map((s) => path.basename(s))
);

let removed = 0;
for (const f of fs.readdirSync(assetsDir)) {
  if (!used.has(f)) {
    fs.unlinkSync(path.join(assetsDir, f));
    removed++;
  }
}

// 去掉占位文件，避免打包进 zip
const keepFile = path.join(dist, '.gitkeep');
if (fs.existsSync(keepFile)) fs.unlinkSync(keepFile);

console.log(`🧹 已清理 ${removed} 个非引用资源，保留 ${used.size} 个`);
