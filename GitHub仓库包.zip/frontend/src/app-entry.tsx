import { createRoot } from 'react-dom/client'
import './index.css'
import { AppHash } from './App.tsx'
import { initNativeApp, setupBackButton } from './lib/native'

// 原生 App 入口（Capacitor 打包用）
// 与网页版共用 AppHash，保证三个产物行为完全一致
createRoot(document.getElementById('root')!).render(<AppHash />)

initNativeApp()
setupBackButton()
