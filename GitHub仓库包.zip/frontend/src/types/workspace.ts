// ── 数据类型定义 ──

export type Priority = 'high' | 'mid' | 'low';

export interface Todo {
  id: string;
  title: string;
  note?: string;
  priority: Priority;
  due?: string; // YYYY-MM-DD
  done: boolean;
  doneAt?: string; // ISO
  createdAt: string; // ISO
}

export type ReminderCategory = 'work' | 'life' | 'health' | 'study' | 'other';

export interface Reminder {
  id: string;
  title: string;
  note?: string;
  category: ReminderCategory;
  date: string; // YYYY-MM-DD
  time?: string; // HH:mm
  done: boolean;
  createdAt: string;
}

export interface Habit {
  id: string;
  name: string;
  emoji: string;
  color: string;
  records: string[]; // 'YYYY-MM-DD'
  createdAt: string;
}

export type EntryType = 'expense' | 'income';
export type EntryCategory =
  | 'food'
  | 'transport'
  | 'shopping'
  | 'home'
  | 'fun'
  | 'medical'
  | 'study'
  | 'other';

export interface Entry {
  id: string;
  amount: number;
  type: EntryType;
  category: EntryCategory;
  note?: string;
  date: string; // YYYY-MM-DD
}

export interface StorageItem {
  id: string;
  name: string;
  category: string;
  location: string;
  qty: number;
  note?: string;
  lentTo?: string;
  lentAt?: string;
  createdAt: string;
}

export type IdeaTag = 'idea' | 'read' | 'watch' | 'collect';

export interface Idea {
  id: string;
  text: string;
  tag: IdeaTag;
  starred: boolean;
  createdAt: string;
}

export interface WeeklyReview {
  good: string;
  bad: string;
  next: string;
  updatedAt: string;
}

export interface Reviews {
  [weekKey: string]: WeeklyReview;
}

export interface Meta {
  lastOpen: string;
  nickname: string;
}
