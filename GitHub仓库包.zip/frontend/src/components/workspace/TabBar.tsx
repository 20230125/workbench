import { useLocation, useNavigate } from 'react-router-dom';
import { motion } from 'framer-motion';
import { Sun, ListChecks, Flame, Grid2x2, type LucideIcon } from 'lucide-react';

const TABS: { path: string; label: string; icon: LucideIcon }[] = [
  { path: '/', label: '今日', icon: Sun },
  { path: '/todos', label: '待办', icon: ListChecks },
  { path: '/habits', label: '打卡', icon: Flame },
  { path: '/more', label: '更多', icon: Grid2x2 },
];

export function TabBar() {
  const nav = useNavigate();
  const { pathname } = useLocation();

  return (
    <nav
      className="fixed bottom-0 left-1/2 z-30 w-full -translate-x-1/2 px-4 pb-[calc(10px+env(safe-area-inset-bottom,0px))] pt-2"
      style={{
        maxWidth: '480px',
        background: 'linear-gradient(to top, var(--background) 58%, transparent)',
      }}
    >
      <div
        className="flex items-center justify-around rounded-[22px] px-2 py-2"
        style={{
          background: 'color-mix(in oklab, var(--card) 92%, transparent)',
          backdropFilter: 'blur(14px) saturate(150%)',
          boxShadow: 'var(--ds-shadow-md)',
          border: '1px solid color-mix(in oklab, var(--border) 65%, transparent)',
        }}
      >
        {TABS.map((t) => {
          const active = pathname === t.path;
          const Icon = t.icon;
          return (
            <button
              key={t.path}
              onClick={() => nav(t.path)}
              aria-label={t.label}
              aria-current={active ? 'page' : undefined}
              className="relative flex flex-1 flex-col items-center gap-0.5 py-1"
            >
              {active && (
                <motion.span
                  layoutId="tab-pill"
                  className="absolute inset-x-1.5 -inset-y-0.5 rounded-[16px]"
                  style={{ background: 'color-mix(in oklab, var(--primary) 13%, transparent)' }}
                  transition={{ type: 'spring', damping: 24, stiffness: 320 }}
                />
              )}
              <Icon
                size={20}
                strokeWidth={active ? 2.6 : 2}
                className="relative z-10 transition-colors"
                style={{ color: active ? 'var(--primary)' : 'var(--muted-foreground)' }}
              />
              <span
                className="relative z-10 text-[10px] font-bold transition-colors"
                style={{ color: active ? 'var(--primary)' : 'var(--muted-foreground)' }}
              >
                {t.label}
              </span>
            </button>
          );
        })}
      </div>
    </nav>
  );
}
