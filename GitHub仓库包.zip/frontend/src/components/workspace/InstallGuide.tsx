import { useEffect, useState } from 'react';
import { Download, Monitor, CheckCircle2, Info } from 'lucide-react';

type Platform = 'ios' | 'huawei' | 'android' | 'desktop' | 'installed' | 'insecure';

/** 判断当前环境，决定给出哪种安装引导 */
function detect(): Platform {
  if (typeof window === 'undefined') return 'desktop';

  // 已经以 App 模式运行
  const standalone =
    window.matchMedia('(display-mode: standalone)').matches ||
    window.matchMedia('(display-mode: fullscreen)').matches ||
    (window.navigator as unknown as { standalone?: boolean }).standalone === true;
  if (standalone) return 'installed';

  // 本地文件或非安全上下文：无法安装
  const { protocol } = window.location;
  if (protocol === 'file:') return 'insecure';

  const ua = navigator.userAgent;
  if (/iPhone|iPad|iPod/i.test(ua)) return 'ios';
  if (/HarmonyOS|HuaweiBrowser|HUAWEI/i.test(ua)) return 'huawei';
  if (/Android/i.test(ua)) return 'android';
  return 'desktop';
}

const GUIDE: Record<Platform, { title: string; lines: string[] }> = {
  installed: {
    title: '已作为 App 运行',
    lines: ['当前是全屏模式，没有浏览器地址栏。'],
  },
  ios: {
    title: '安装到桌面（全屏）',
    lines: ['用 Safari 打开本页', '点底部「分享」按钮', '选「添加到主屏幕」'],
  },
  huawei: {
    title: '安装到桌面（全屏）',
    lines: ['点右下角菜单（三横线）', '选「添加到桌面」', '确认后桌面出现「工作台」图标'],
  },
  android: {
    title: '安装到桌面（全屏）',
    lines: ['点右上角菜单（三个点）', '选「安装应用」或「添加到主屏幕」', '确认后桌面出现图标'],
  },
  desktop: {
    title: '安装到桌面（全屏）',
    lines: ['看地址栏右侧的安装图标', '或点菜单 →「安装 我的工作台」', '安装后独立窗口运行，无地址栏'],
  },
  insecure: {
    title: '本地文件不支持安装',
    lines: [
      '当前用 file:// 打开，浏览器禁止安装。',
      '把页面托管成 https 网址后即可安装。',
      '详见「手机部署说明」。',
    ],
  },
};

export function InstallGuide() {
  const [platform, setPlatform] = useState<Platform>('desktop');

  useEffect(() => {
    setPlatform(detect());
    // 从浏览器切到 App 模式时更新
    const mq = window.matchMedia('(display-mode: standalone)');
    const onChange = () => setPlatform(detect());
    mq.addEventListener?.('change', onChange);
    return () => mq.removeEventListener?.('change', onChange);
  }, []);

  const guide = GUIDE[platform];
  const done = platform === 'installed';
  const blocked = platform === 'insecure';
  const Icon = done ? CheckCircle2 : blocked ? Info : Download;

  return (
    <div
      className="rounded-[var(--radius-lg)] p-3.5"
      style={{
        background: done
          ? 'color-mix(in oklab, var(--success) 10%, var(--card))'
          : 'color-mix(in oklab, var(--primary) 8%, var(--card))',
        border: `1px solid color-mix(in oklab, ${done ? 'var(--success)' : 'var(--primary)'} 22%, transparent)`,
      }}
    >
      <p className="flex items-center gap-1.5 text-[length:var(--font-size-small)] font-extrabold">
        <Icon size={13} strokeWidth={2.8} style={{ color: done ? 'var(--success)' : 'var(--primary)' }} />
        {guide.title}
      </p>
      <ol className="mt-1.5 space-y-1 pl-4 text-[10px] leading-relaxed text-muted-foreground">
        {guide.lines.map((line, i) => (
          <li key={i} className="list-decimal">
            {line}
          </li>
        ))}
      </ol>
    </div>
  );
}

/** 全屏状态指示器（用在页面底部，便于确认当前是否 App 模式） */
export function DisplayModeBadge() {
  const [mode, setMode] = useState('Browser');

  useEffect(() => {
    const check = () => {
      if (window.matchMedia('(display-mode: fullscreen)').matches) setMode('Fullscreen');
      else if (window.matchMedia('(display-mode: standalone)').matches) setMode('Standalone');
      else if (window.matchMedia('(display-mode: minimal-ui)').matches) setMode('MinimalUI');
      else setMode('Browser');
    };
    check();
    const lists = ['fullscreen', 'standalone', 'minimal-ui'].map((m) =>
      window.matchMedia(`(display-mode: ${m})`)
    );
    lists.forEach((l) => l.addEventListener?.('change', check));
    return () => lists.forEach((l) => l.removeEventListener?.('change', check));
  }, []);

  const isApp = mode !== 'Browser';
  return (
    <p className="flex items-center justify-center gap-1 text-[9px] font-semibold text-muted-foreground/70">
      <Monitor size={9} strokeWidth={2.6} />
      {isApp ? `App 模式 · ${mode}` : '浏览器模式'}
    </p>
  );
}
