import type { ReactNode } from 'react';
import { useNavigate } from 'react-router-dom';
import { motion } from 'framer-motion';
import { ArrowLeft, Plus } from 'lucide-react';
import { cn } from '@/lib/utils';

/* ───────── 页面容器 ───────── */
export function Screen({
  children,
  className,
}: {
  children: ReactNode;
  className?: string;
}) {
  return (
    <div className={cn('phone-shell font-[var(--font-family)]', className)}>{children}</div>
  );
}

/* ───────── 页面头部 ───────── */
export function PageHeader({
  title,
  subtitle,
  action,
  back = true,
}: {
  title: string;
  subtitle?: string;
  action?: ReactNode;
  back?: boolean;
}) {
  const nav = useNavigate();
  return (
    <header
      className="sticky top-0 z-20 flex items-center gap-3 px-5 pb-3"
      style={{
        // 全屏 App 模式下内容会顶到状态栏下方，需让出刘海/状态栏高度
        paddingTop: 'calc(1rem + env(safe-area-inset-top, 0px))',
        background: 'color-mix(in oklab, var(--background) 86%, transparent)',
        backdropFilter: 'blur(16px)',
        borderBottom: '1px solid color-mix(in oklab, var(--border) 60%, transparent)',
      }}
    >
      {back && (
        <button
          onClick={() => nav(-1)}
          aria-label="返回"
          className="press flex size-9 shrink-0 items-center justify-center rounded-full bg-secondary text-foreground/70 hover:text-foreground"
        >
          <ArrowLeft size={18} strokeWidth={2.4} />
        </button>
      )}
      <div className="min-w-0 flex-1">
        <h1 className="truncate text-[length:var(--font-size-title)] font-extrabold tracking-tight">
          {title}
        </h1>
        {subtitle && (
          <p className="truncate text-[length:var(--font-size-small)] text-muted-foreground">
            {subtitle}
          </p>
        )}
      </div>
      {action}
    </header>
  );
}

/* ───────── 区块标题 ───────── */
export function SectionTitle({
  children,
  hint,
  onMore,
}: {
  children: ReactNode;
  hint?: ReactNode;
  onMore?: () => void;
}) {
  return (
    <div className="mb-2.5 flex items-end justify-between px-1">
      <h2 className="text-[length:var(--font-size-label)] font-bold tracking-wide text-foreground">
        {children}
      </h2>
      {hint && (
        <button
          onClick={onMore}
          className="text-[length:var(--font-size-small)] font-medium text-muted-foreground transition-colors hover:text-primary"
        >
          {hint}
        </button>
      )}
    </div>
  );
}

/* ───────── 卡片 ───────── */
export function Card({
  children,
  className,
  onClick,
}: {
  children: ReactNode;
  className?: string;
  onClick?: () => void;
}) {
  return (
    <div
      onClick={onClick}
      className={cn(
        'rounded-[var(--radius-lg)] bg-card p-4',
        'shadow-[var(--ds-shadow-sm)]',
        'border border-[color-mix(in_oklab,var(--border)_55%,transparent)]',
        onClick && 'press cursor-pointer',
        className
      )}
    >
      {children}
    </div>
  );
}

/* ───────── 空状态 ───────── */
export function Empty({ icon, text, hint }: { icon: ReactNode; text: string; hint?: string }) {
  return (
    <div className="flex flex-col items-center justify-center gap-2 py-12 text-center">
      <div className="flex size-14 items-center justify-center rounded-2xl bg-secondary text-muted-foreground/60">
        {icon}
      </div>
      <p className="text-[length:var(--font-size-label)] font-semibold text-foreground/70">
        {text}
      </p>
      {hint && (
        <p className="max-w-[220px] text-[length:var(--font-size-small)] leading-relaxed text-muted-foreground">
          {hint}
        </p>
      )}
    </div>
  );
}

/* ───────── 浮动新增按钮 ───────── */
export function Fab({ onClick, label = '新增' }: { onClick: () => void; label?: string }) {
  return (
    <motion.button
      initial={{ scale: 0, rotate: -30 }}
      animate={{ scale: 1, rotate: 0 }}
      transition={{ type: 'spring', damping: 14, stiffness: 260, delay: 0.15 }}
      whileTap={{ scale: 0.9 }}
      onClick={onClick}
      aria-label={label}
      className="fixed bottom-[calc(96px+env(safe-area-inset-bottom,0px))] right-[max(20px,calc(50%-220px))] z-30 flex size-14 items-center justify-center rounded-full text-white shadow-[0_10px_24px_-6px_color-mix(in_oklab,var(--primary)_65%,transparent)]"
      style={{ background: 'var(--primary)' }}
    >
      <Plus size={26} strokeWidth={2.6} />
    </motion.button>
  );
}

/* ───────── 分段控件 ───────── */
export function Segmented<T extends string>({
  value,
  onChange,
  options,
}: {
  value: T;
  onChange: (v: T) => void;
  options: { value: T; label: string }[];
}) {
  return (
    <div className="flex gap-1 rounded-full bg-secondary p-1">
      {options.map((o) => {
        const active = o.value === value;
        return (
          <button
            key={o.value}
            onClick={() => onChange(o.value)}
            className={cn(
              'relative flex-1 rounded-full px-3 py-1.5 text-[length:var(--font-size-small)] font-bold transition-colors',
              active ? 'text-primary-foreground' : 'text-muted-foreground hover:text-foreground'
            )}
          >
            {active && (
              <motion.span
                layoutId="segmented-pill"
                className="absolute inset-0 rounded-full"
                style={{ background: 'var(--primary)' }}
                transition={{ type: 'spring', damping: 22, stiffness: 300 }}
              />
            )}
            <span className="relative z-10">{o.label}</span>
          </button>
        );
      })}
    </div>
  );
}

/* ───────── 标签 ───────── */
export function Tag({
  children,
  color,
  className,
}: {
  children: ReactNode;
  color?: string;
  className?: string;
}) {
  return (
    <span
      className={cn(
        'inline-flex items-center rounded-full px-2 py-0.5 text-[10px] font-bold leading-normal',
        className
      )}
      style={{
        color: color || 'var(--muted-foreground)',
        background: color
          ? `color-mix(in oklab, ${color} 14%, transparent)`
          : 'var(--secondary)',
      }}
    >
      {children}
    </span>
  );
}
