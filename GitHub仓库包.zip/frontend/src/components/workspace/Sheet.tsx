import type { ReactNode } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { X } from 'lucide-react';

/* 底部弹出层（轻量，不依赖 radix） */
export function Sheet({
  open,
  onClose,
  title,
  children,
}: {
  open: boolean;
  onClose: () => void;
  title: string;
  children: ReactNode;
}) {
  return (
    <AnimatePresence>
      {open && (
        <>
          <motion.div
            className="fixed inset-0 z-40 bg-black/35 backdrop-blur-[2px]"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            transition={{ duration: 0.2 }}
            onClick={onClose}
          />
          <motion.div
            className="fixed left-1/2 z-50 w-full max-w-[480px] -translate-x-1/2 rounded-t-[26px] bg-card px-5 pt-3 pb-[calc(20px+env(safe-area-inset-bottom,0px))] shadow-[var(--ds-shadow-xl)]"
            style={{ bottom: 0 }}
            initial={{ y: '100%' }}
            animate={{ y: 0 }}
            exit={{ y: '100%' }}
            transition={{ type: 'spring', damping: 30, stiffness: 320 }}
          >
            <div className="mx-auto mb-3 h-1.5 w-10 rounded-full bg-border" />
            <div className="mb-4 flex items-center justify-between">
              <h3 className="text-[length:var(--font-size-title)] font-extrabold tracking-tight">
                {title}
              </h3>
              <button
                onClick={onClose}
                aria-label="关闭"
                className="press flex size-8 items-center justify-center rounded-full bg-secondary text-muted-foreground"
              >
                <X size={16} strokeWidth={2.6} />
              </button>
            </div>
            <div className="max-h-[70vh] overflow-y-auto">{children}</div>
          </motion.div>
        </>
      )}
    </AnimatePresence>
  );
}

/* 表单字段 */
export function Field({ label, children }: { label: string; children: ReactNode }) {
  return (
    <label className="mb-3 block">
      <span className="mb-1.5 block text-[length:var(--font-size-small)] font-bold text-muted-foreground">
        {label}
      </span>
      {children}
    </label>
  );
}

const inputCls =
  'w-full rounded-[14px] border border-border bg-secondary/60 px-3.5 py-2.5 text-[length:var(--font-size-body)] font-medium text-foreground outline-none transition-colors placeholder:text-muted-foreground/70 focus:border-primary focus:bg-card';

export function TextInput(props: React.InputHTMLAttributes<HTMLInputElement>) {
  return <input {...props} className={inputCls + ' ' + (props.className || '')} />;
}

export function TextArea(props: React.TextareaHTMLAttributes<HTMLTextAreaElement>) {
  return (
    <textarea
      {...props}
      className={inputCls + ' resize-none leading-relaxed ' + (props.className || '')}
    />
  );
}

export function SelectInput(props: React.SelectHTMLAttributes<HTMLSelectElement>) {
  return (
    <select
      {...props}
      className={inputCls + ' appearance-none pr-8 ' + (props.className || '')}
      style={{
        backgroundImage:
          "url(\"data:image/svg+xml;utf8,<svg xmlns='http://www.w3.org/2000/svg' width='14' height='14' viewBox='0 0 24 24' fill='none' stroke='%23888' stroke-width='3' stroke-linecap='round'><path d='M6 9l6 6 6-6'/></svg>\")",
        backgroundRepeat: 'no-repeat',
        backgroundPosition: 'right 12px center',
      }}
    />
  );
}

/* 主按钮 */
export function PrimaryButton({
  children,
  onClick,
  disabled,
  type = 'button',
  className = '',
}: {
  children: ReactNode;
  onClick?: () => void;
  disabled?: boolean;
  type?: 'button' | 'submit';
  className?: string;
}) {
  return (
    <button
      type={type}
      onClick={onClick}
      disabled={disabled}
      className={
        'press flex w-full items-center justify-center gap-2 rounded-[15px] py-3 text-[length:var(--font-size-body)] font-extrabold text-primary-foreground transition-opacity disabled:opacity-40 ' +
        className
      }
      style={{
        background: 'var(--primary)',
        boxShadow: '0 8px 20px -8px color-mix(in oklab, var(--primary) 70%, transparent)',
      }}
    >
      {children}
    </button>
  );
}

/* 选项胶囊组 */
export function ChipGroup<T extends string>({
  value,
  onChange,
  options,
}: {
  value: T;
  onChange: (v: T) => void;
  options: { value: T; label: string; color?: string }[];
}) {
  return (
    <div className="flex flex-wrap gap-2">
      {options.map((o) => {
        const active = o.value === value;
        return (
          <button
            key={o.value}
            type="button"
            onClick={() => onChange(o.value)}
            className="press rounded-full px-3 py-1.5 text-[length:var(--font-size-small)] font-bold transition-colors"
            style={
              active
                ? {
                    background: o.color || 'var(--primary)',
                    color: '#fff',
                  }
                : {
                    background: 'var(--secondary)',
                    color: 'var(--muted-foreground)',
                  }
            }
          >
            {o.label}
          </button>
        );
      })}
    </div>
  );
}
