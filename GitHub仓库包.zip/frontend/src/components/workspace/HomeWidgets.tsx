import { useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { motion } from 'framer-motion';
import { ArrowUpRight, Check, Flame, RefreshCw, Clock3 } from 'lucide-react';
import { greeting, todayKey, weekLabel, weekDays, relativeDay } from '@/lib/date';
import { quoteOfDay } from '@/lib/quotes';
import { useHabits, useTodos, useReminders } from '@/hooks/useWorkspace';
import { globalStreak } from '@/lib/stats';
import type { Stats } from '@/lib/stats';

/* ── 实时时钟 ── */
function useClock() {
  const [now, setNow] = useState(new Date());
  useEffect(() => {
    const t = setInterval(() => setNow(new Date()), 1000);
    return () => clearInterval(t);
  }, []);
  return now;
}

const WEEK_SHORT = ['一', '二', '三', '四', '五', '六', '日'];

export function HeroClock({ stats }: { stats: Stats }) {
  const now = useClock();
  const nav = useNavigate();
  const today = todayKey();
  const { habits, check } = useHabits();
  const [quoteOffset, setQuoteOffset] = useState(0);

  const allCheckedToday = habits.length > 0 && habits.every((h) => h.records.includes(today));
  const checkedCount = habits.filter((h) => h.records.includes(today)).length;
  const streak = globalStreak(habits);
  const days = weekDays();

  const h = String(now.getHours()).padStart(2, '0');
  const m = String(now.getMinutes()).padStart(2, '0');
  const s = String(now.getSeconds()).padStart(2, '0');

  const doCheckAll = () => {
    if (allCheckedToday) return;
    habits.forEach((hb) => {
      if (!hb.records.includes(today)) check(hb.id, today);
    });
  };

  return (
    <section
      className="hero-gradient relative overflow-hidden px-5 pb-5"
      style={{ paddingTop: 'calc(1.5rem + env(safe-area-inset-top, 0px))' }}
    >
      {/* 装饰光斑 */}
      <div
        className="pointer-events-none absolute -right-10 -top-14 size-40 rounded-full opacity-40 blur-2xl"
        style={{ background: 'color-mix(in oklab, var(--primary) 45%, transparent)' }}
      />
      <div
        className="pointer-events-none absolute -left-12 top-24 size-32 rounded-full opacity-30 blur-2xl"
        style={{ background: 'oklch(0.85 0.13 84)' }}
      />

      {/* 时钟行 */}
      <div className="relative flex items-start justify-between">
        <div>
          <p className="mb-0.5 flex items-center gap-1 text-[length:var(--font-size-small)] font-semibold text-muted-foreground">
            <Clock3 size={12} strokeWidth={2.5} />
            {now.getMonth() + 1}月{now.getDate()}日 · {weekLabel(now)} · {greeting(now.getHours())}
          </p>
          <div className="flex items-baseline gap-1">
            <motion.span
              className="tnum font-extrabold leading-none tracking-[-0.03em]"
              style={{ fontSize: '3.25rem' }}
              initial={{ opacity: 0, y: 8 }}
              animate={{ opacity: 1, y: 0 }}
            >
              {h}
              <span className="mx-0.5 animate-pulse font-light opacity-40">:</span>
              {m}
            </motion.span>
            <span className="tnum text-[length:var(--font-size-label)] font-bold text-muted-foreground">
              {s}
            </span>
          </div>
        </div>

        {/* 打卡圆钮 */}
        <button
          onClick={doCheckAll}
          aria-label="今日打卡"
          className={`press relative flex size-[68px] shrink-0 flex-col items-center justify-center rounded-full text-white ${
            allCheckedToday ? '' : 'pulse-ring'
          }`}
          style={{
            background: allCheckedToday
              ? 'linear-gradient(140deg, var(--theme-green), color-mix(in oklab, var(--theme-green) 70%, white))'
              : 'linear-gradient(140deg, var(--primary), color-mix(in oklab, var(--primary) 62%, oklch(0.82 0.14 60)))',
            boxShadow: '0 10px 26px -8px color-mix(in oklab, var(--primary) 60%, transparent)',
          }}
        >
          {allCheckedToday ? (
            <motion.div
              initial={{ scale: 0.6, rotate: -20 }}
              animate={{ scale: 1, rotate: 0 }}
              className="flex flex-col items-center"
            >
              <Check size={24} strokeWidth={3.2} />
              <span className="mt-0.5 text-[10px] font-extrabold">已打卡</span>
            </motion.div>
          ) : (
            <div className="flex flex-col items-center">
              <Flame size={20} strokeWidth={2.6} />
              <span className="mt-0.5 text-[11px] font-extrabold">打卡</span>
              <span className="text-[9px] font-bold opacity-80">
                {checkedCount}/{habits.length}
              </span>
            </div>
          )}
        </button>
      </div>

      {/* 激励语 */}
      <div className="relative mt-4 flex items-start gap-2 rounded-[16px] bg-[color-mix(in_oklab,var(--card)_72%,transparent)] p-3 backdrop-blur-sm">
        <div
          className="mt-0.5 shrink-0 rounded-md px-1.5 py-0.5 text-[9px] font-extrabold text-white"
          style={{ background: 'var(--primary)' }}
        >
          每日一句
        </div>
        <p className="flex-1 text-[length:var(--font-size-label)] font-semibold leading-snug text-foreground/85">
          {quoteOfDay(now, quoteOffset)}
        </p>
        <button
          onClick={(e) => {
            e.stopPropagation();
            setQuoteOffset((v) => v + 1);
          }}
          aria-label="换一句"
          className="press mt-0.5 flex size-6 shrink-0 items-center justify-center rounded-full text-muted-foreground hover:text-primary"
        >
          <RefreshCw size={13} strokeWidth={2.6} />
        </button>
      </div>

      {/* 本周打卡条 */}
      <div className="relative mt-4 flex items-start justify-between gap-1">
        {days.map((d, i) => {
          const isToday = d === today;
          const dayHabits = habits.filter((hb) => hb.records.includes(d));
          const rate = habits.length ? dayHabits.length / habits.length : 0;
          const isFuture = d > today;
          return (
            <div key={d} className="flex flex-1 flex-col items-center gap-1">
              <span
                className="text-[9px] font-bold"
                style={{ color: isToday ? 'var(--primary)' : 'var(--muted-foreground)' }}
              >
                {WEEK_SHORT[i]}
              </span>
              <div
                className="flex size-7 items-center justify-center rounded-full transition-all"
                style={{
                  background:
                    rate > 0
                      ? `color-mix(in oklab, var(--primary) ${Math.round(rate * 100)}%, var(--secondary))`
                      : isFuture
                        ? 'transparent'
                        : 'var(--secondary)',
                  border: isToday ? '1.5px solid var(--primary)' : '1.5px solid transparent',
                  opacity: isFuture ? 0.35 : 1,
                }}
              >
                {rate >= 1 ? (
                  <Check size={13} color="#fff" strokeWidth={3.4} />
                ) : (
                  <span
                    className="text-[10px] font-extrabold"
                    style={{
                      color: rate > 0.5 ? '#fff' : 'var(--muted-foreground)',
                    }}
                  >
                    {dayHabits.length || ''}
                  </span>
                )}
              </div>
            </div>
          );
        })}
      </div>

      {/* 连续天数提示 */}
      <button
        onClick={() => nav('/habits')}
        className="press relative mt-3 flex w-full items-center justify-between rounded-[14px] bg-[color-mix(in_oklab,var(--primary)_10%,transparent)] px-3 py-2"
      >
        <span className="flex items-center gap-1.5 text-[length:var(--font-size-small)] font-bold text-primary">
          <Flame size={14} strokeWidth={2.8} />
          <span>连续打卡</span>
          <span className="tnum" style={{ fontSize: '1.05em' }}>{streak}</span>
          <span>天</span>
          {stats.habitTotal > 0 && (
            <span className="font-medium text-muted-foreground">
              · 今日 {stats.todayHabitsDone}/{stats.habitTotal}
            </span>
          )}
        </span>
        <ArrowUpRight size={14} className="text-primary" strokeWidth={2.8} />
      </button>
    </section>
  );
}

/* ── 统计卡片 ── */

interface StatCardProps {
  label: string;
  value: string;
  unit?: string;
  hint?: string;
  trend?: number;
  color: string;
  icon: React.ReactNode;
  onClick: () => void;
  wide?: boolean;
  delay?: number;
}

export function StatCard({
  label,
  value,
  unit,
  hint,
  trend,
  color,
  icon,
  onClick,
  wide,
  delay = 0,
}: StatCardProps) {
  return (
    <motion.button
      onClick={onClick}
      initial={{ opacity: 0, y: 14 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.42, delay, ease: [0.22, 0.9, 0.3, 1] }}
      whileTap={{ scale: 0.965 }}
      className={`relative flex flex-col justify-between overflow-hidden rounded-[var(--radius-lg)] border border-[color-mix(in_oklab,var(--border)_50%,transparent)] bg-card p-3.5 text-left shadow-[var(--ds-shadow-sm)] ${
        wide ? 'col-span-1' : ''
      }`}
      style={{ minHeight: 96 }}
    >
      <div
        className="pointer-events-none absolute -right-6 -top-6 size-16 rounded-full opacity-[0.14]"
        style={{ background: color }}
      />
      <div className="flex items-center justify-between">
        <span className="flex size-7 items-center justify-center rounded-[9px]" style={{ background: `color-mix(in oklab, ${color} 15%, transparent)`, color }}>
          {icon}
        </span>
        {typeof trend === 'number' && trend !== 0 && (
          <span
            className="rounded-full px-1.5 py-0.5 text-[9px] font-extrabold"
            style={{
              color: trend > 0 ? 'var(--theme-red)' : 'var(--theme-green)',
              background:
                trend > 0
                  ? 'color-mix(in oklab, var(--theme-red) 12%, transparent)'
                  : 'color-mix(in oklab, var(--theme-green) 12%, transparent)',
            }}
          >
            {trend > 0 ? '↑' : '↓'}
            {Math.abs(Math.round(trend))}%
          </span>
        )}
      </div>
      <div className="mt-1.5">
        <div className="flex items-baseline gap-0.5">
          <span className="tnum text-[1.45rem] font-extrabold leading-none tracking-tight">
            {value}
          </span>
          {unit && (
            <span className="text-[10px] font-bold text-muted-foreground">{unit}</span>
          )}
        </div>
        <p className="mt-1 truncate text-[10px] font-bold text-muted-foreground">{label}</p>
        {hint && (
          <p className="mt-0.5 truncate text-[9px] font-medium text-muted-foreground/75">{hint}</p>
        )}
      </div>
    </motion.button>
  );
}

/* ── 快捷入口 ── */
export interface QuickItem {
  path: string;
  label: string;
  desc: string;
  icon: React.ReactNode;
  color: string;
  badge?: string;
}

export function QuickGrid({ items }: { items: QuickItem[] }) {
  const nav = useNavigate();
  return (
    <div
      className="gap-2"
      style={{ display: 'grid', gridTemplateColumns: 'repeat(4, minmax(0, 1fr))' }}
    >
      {items.map((it, i) => (
        <motion.button
          key={it.path}
          onClick={() => nav(it.path)}
          initial={{ opacity: 0, scale: 0.9 }}
          animate={{ opacity: 1, scale: 1 }}
          transition={{ duration: 0.3, delay: 0.04 * i }}
          whileTap={{ scale: 0.92 }}
          className="group relative flex flex-col items-center gap-1.5 rounded-[16px] bg-card px-1 py-3 shadow-[var(--ds-shadow-sm)] border border-[color-mix(in_oklab,var(--border)_50%,transparent)]"
        >
          <span
            className="flex size-9 items-center justify-center rounded-[12px] transition-transform duration-200 group-hover:scale-105"
            style={{
              background: `color-mix(in oklab, ${it.color} 14%, transparent)`,
              color: it.color,
            }}
          >
            {it.icon}
          </span>
          <span className="text-[10px] font-bold leading-tight text-foreground/85">
            {it.label}
          </span>
          {it.badge && (
            <span
              className="absolute right-1.5 top-1.5 rounded-full px-1 py-[1px] text-[8px] font-extrabold text-white"
              style={{ background: it.color }}
            >
              {it.badge}
            </span>
          )}
        </motion.button>
      ))}
    </div>
  );
}

/* ── 今日待办迷你列表 ── */
export function TodayPeek() {
  const nav = useNavigate();
  const { todos, toggle } = useTodos();
  const { reminders } = useReminders();
  const today = todayKey();

  const list = [
    ...reminders
      .filter((r) => !r.done && r.date <= today)
      .slice(0, 3)
      .map((r) => ({
        id: 'r-' + r.id,
        title: r.title,
        time: r.time,
        tag: relativeDay(r.date),
        kind: 'reminder' as const,
      })),
    ...todos
      .filter((t) => !t.done)
      .slice(0, 3)
      .map((t) => ({
        id: 't-' + t.id,
        title: t.title,
        time: undefined,
        tag: t.due ? relativeDay(t.due) : '待办',
        kind: 'todo' as const,
      })),
  ].slice(0, 5);

  if (!list.length)
    return (
      <div className="rounded-[14px] border border-dashed border-border bg-card/50 px-3 py-4 text-center">
        <p className="text-[length:var(--font-size-small)] font-bold text-muted-foreground">
          今天还没有待办
        </p>
        <p className="mt-0.5 text-[10px] text-muted-foreground/70">轻轻松松，也是一种状态</p>
      </div>
    );

  return (
    <div className="space-y-1.5">
      {list.map((it) => (
        <div
          key={it.id}
          className="flex items-center gap-2.5 rounded-[14px] bg-card px-3 py-2.5 border border-[color-mix(in_oklab,var(--border)_50%,transparent)]"
        >
          <button
            onClick={() => {
              if (it.kind === 'todo') toggle(it.id.slice(2));
            }}
            aria-label="完成"
            className="flex size-[18px] shrink-0 items-center justify-center rounded-full border-2 transition-all hover:border-primary"
            style={{ borderColor: 'var(--border)' }}
          />
          <span className="min-w-0 flex-1 truncate text-[length:var(--font-size-label)] font-semibold">
            {it.title}
          </span>
          <span
            className="shrink-0 rounded-full px-1.5 py-0.5 text-[9px] font-bold"
            style={{
              background: 'var(--secondary)',
              color: 'var(--muted-foreground)',
            }}
          >
            {it.tag}
          </span>
        </div>
      ))}
      <button
        onClick={() => nav('/todos')}
        className="press w-full rounded-[12px] py-2 text-[length:var(--font-size-small)] font-bold text-primary/80 hover:bg-[color-mix(in_oklab,var(--primary)_8%,transparent)]"
      >
        查看全部 →
      </button>
    </div>
  );
}
