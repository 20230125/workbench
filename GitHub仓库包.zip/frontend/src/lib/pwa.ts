/**
 * 注册 Service Worker，使应用满足「可安装为桌面 App」的条件。
 * 仅在 http/https 下注册：file:// 协议不支持 SW，强行注册会抛错。
 */
export function registerServiceWorker() {
  if (typeof window === 'undefined') return;
  if (!('serviceWorker' in navigator)) return;

  const { protocol, hostname } = window.location;
  const isHttp = protocol === 'http:' || protocol === 'https:';
  // localhost 之外必须 https；localhost 允许 http 便于本地调试
  const isLocalhost = hostname === 'localhost' || hostname === '127.0.0.1';
  if (!isHttp || (protocol !== 'https:' && !isLocalhost)) return;

  window.addEventListener('load', () => {
    navigator.serviceWorker.register('./sw.js').catch(() => {
      /* 注册失败不影响正常使用 */
    });
  });
}
