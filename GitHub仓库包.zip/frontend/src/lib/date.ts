// ── 日期工具（全部基于本地时区，避免 UTC 偏移造成的跨天问题）──

export const pad2 = (n: number) => String(n).padStart(2, '0');

/** 'YYYY-MM-DD' of a Date (local) */
export function toKey(d: Date): string {
  return `${d.getFullYear()}-${pad2(d.getMonth() + 1)}-${pad2(d.getDate())}`;
}

export const todayKey = () => toKey(new Date());

/** 'YYYY-MM' */
export function monthKey(d: Date = new Date()): string {
  return `${d.getFullYear()}-${pad2(d.getMonth() + 1)}`;
}

export function parseKey(key: string): Date {
  const [y, m, d] = key.split('-').map(Number);
  return new Date(y, (m || 1) - 1, d || 1);
}

export function addDays(key: string, n: number): string {
  const d = parseKey(key);
  d.setDate(d.getDate() + n);
  return toKey(d);
}

export function diffDays(a: string, b: string): number {
  const t1 = parseKey(a).getTime();
  const t2 = parseKey(b).getTime();
  return Math.round((t1 - t2) / 86400000);
}

const WEEK_LABELS = ['周日', '周一', '周二', '周三', '周四', '周五', '周六'];
export const weekLabel = (d: Date) => WEEK_LABELS[d.getDay()];

/** 周一为一周起点，返回本周一的 key */
export function weekStartKey(key: string = todayKey()): string {
  const d = parseKey(key);
  const day = d.getDay(); // 0=Sun
  const offset = day === 0 ? -6 : 1 - day;
  d.setDate(d.getDate() + offset);
  return toKey(d);
}

export function weekKeyOf(key: string = todayKey()): string {
  return weekStartKey(key);
}

/** 本周 7 天（周一 → 周日） */
export function weekDays(key: string = todayKey()): string[] {
  const start = weekStartKey(key);
  return Array.from({ length: 7 }, (_, i) => addDays(start, i));
}

export function monthOf(key: string): string {
  return key.slice(0, 7);
}

export function daysInMonth(mKey: string): number {
  const [y, m] = mKey.split('-').map(Number);
  return new Date(y, m, 0).getDate();
}

export function prevMonth(mKey: string): string {
  const [y, m] = mKey.split('-').map(Number);
  const d = new Date(y, m - 2, 1);
  return monthKey(d);
}

/** 某月 1 号是周几（周一=0） */
export function firstWeekdayOfMonth(mKey: string): number {
  const [y, m] = mKey.split('-').map(Number);
  const day = new Date(y, m - 1, 1).getDay();
  return day === 0 ? 6 : day - 1;
}

export function formatMoney(n: number): string {
  if (Math.abs(n) >= 10000) return (n / 10000).toFixed(1) + 'w';
  return n.toLocaleString('zh-CN', { maximumFractionDigits: n % 1 === 0 ? 0 : 2 });
}

export function formatDateCn(key: string): string {
  const d = parseKey(key);
  return `${d.getMonth() + 1}月${d.getDate()}日`;
}

/** 相对日期描述 */
export function relativeDay(key: string): string {
  const t = todayKey();
  const diff = diffDays(key, t);
  if (diff === 0) return '今天';
  if (diff === 1) return '明天';
  if (diff === -1) return '昨天';
  if (diff === 2) return '后天';
  if (diff < 0) return formatDateCn(key);
  if (diff <= 7) return `${diff} 天后`;
  return formatDateCn(key);
}

export function greeting(h: number): string {
  if (h < 5) return '夜深了';
  if (h < 9) return '早上好';
  if (h < 12) return '上午好';
  if (h < 14) return '中午好';
  if (h < 18) return '下午好';
  if (h < 22) return '晚上好';
  return '该休息了';
}
