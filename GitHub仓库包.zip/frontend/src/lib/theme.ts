/**
 * 主题 / 外观系统
 * ---------------------------------------------------------------
 * 设计思路：
 *  - 不直接暴露 oklch 数值给用户（太难理解），而是提供「色相」这一维度。
 *    应用内所有配色都基于 var(--primary) / var(--accent) 等变量推导，
 *    因此只要在 <html> 上覆盖这些变量，全站配色就会整体换色，
 *    且原有的明度/饱和度关系保持不变，不会出现刺眼或对比度不足。
 *  - 明暗模式、圆角、字号、紧凑度作为独立开关。
 *  - 全部写入内联 CSS 变量，不依赖任何第三方库，切页/刷新均即时生效。
 */

export type ThemeMode = 'light' | 'dark' | 'auto';

export interface ThemeState {
  /** 色相 0-360（31 = 暖橙珊瑚，应用原始配色） */
  hue: number;
  /** 饱和度倍率 0.55 ~ 1.5 */
  chroma: number;
  mode: ThemeMode;
  /** 圆角倍率 0 ~ 1.7（0 = 直角，1 = 默认） */
  radius: number;
  /** 字号倍率 0.90 ~ 1.15 */
  fontScale: number;
}

export const DEFAULT_THEME: ThemeState = {
  hue: 31,
  chroma: 1,
  mode: 'light',
  radius: 1,
  fontScale: 1,
};

export interface Preset {
  key: string;
  name: string;
  hue: number;
  chroma: number;
}

/** 预设配色，选完仍可继续用滑块微调 */
export const PRESETS: Preset[] = [
  { key: 'coral', name: '暖橙珊瑚', hue: 31, chroma: 1 },
  { key: 'rose', name: '玫瑰粉', hue: 5, chroma: 1.05 },
  { key: 'amber', name: '琥珀金', hue: 70, chroma: 0.95 },
  { key: 'leaf', name: '青竹绿', hue: 152, chroma: 0.85 },
  { key: 'teal', name: '湖水青', hue: 195, chroma: 0.9 },
  { key: 'ocean', name: '深海蓝', hue: 245, chroma: 1 },
  { key: 'violet', name: '薰衣草', hue: 295, chroma: 0.95 },
  { key: 'clay', name: '陶土灰', hue: 45, chroma: 0.5 },
];

function oklch(l: number, c: number, h: number): string {
  const hue = ((h % 360) + 360) % 360;
  return `oklch(${l.toFixed(3)} ${Math.max(0, c).toFixed(4)} ${hue.toFixed(1)})`;
}

/**
 * 根据主题设置生成 CSS 变量表。
 * 直接覆盖 index.css 中 :root / .dark 定义的同名变量，
 * 因此无需改动任何组件代码。
 */
export function buildVars(t: ThemeState): Record<string, string> {
  const h = t.hue;
  const k = t.chroma;

  // 主色：浅色模式 L≈0.694，深色模式略提亮保证对比度
  const primaryLight = oklch(0.694, 0.163 * k, h);

  return {
    // light
    '--primary': primaryLight,
    '--ring': primaryLight,
    '--accent': oklch(0.945, 0.028 * k, h),
    '--accent-foreground': oklch(0.36, 0.09 * k, h),
    '--secondary': oklch(0.962, 0.014 * k, h),
    '--secondary-foreground': oklch(0.32, 0.03 * k, h),
    '--muted': oklch(0.962, 0.012 * k, h),
    '--sidebar-primary': primaryLight,
    '--sidebar-accent': oklch(0.945, 0.028 * k, h),
    '--sidebar-accent-foreground': oklch(0.36, 0.09 * k, h),
    // hero 区（首页顶部大卡）
    '--hero': primaryLight,
    // 圆角 / 字号
    '--radius': `${(1.125 * t.radius).toFixed(3)}rem`,
    '--theme-font-scale': t.fontScale.toFixed(3),
  };
}

/** 深色模式下需要单独覆盖的变量 */
export function buildDarkVars(t: ThemeState): Record<string, string> {
  const h = t.hue;
  const k = t.chroma;
  const primaryDark = oklch(0.712, 0.155 * k, h);

  return {
    '--primary': primaryDark,
    '--ring': primaryDark,
    '--accent': oklch(0.312, 0.032 * k, h),
    '--accent-foreground': oklch(0.94, 0.012 * k, h),
    '--secondary': oklch(0.278, 0.016 * k, h),
    '--secondary-foreground': oklch(0.94, 0.01 * k, h),
    '--muted': oklch(0.278, 0.016 * k, h),
    '--sidebar-primary': primaryDark,
    '--sidebar-accent': oklch(0.312, 0.032 * k, h),
    '--hero': primaryDark,
  };
}

/** 把一个值同时写成「针对根节点的 light 值」或「深色值」 */
export function applyTheme(t: ThemeState) {
  if (typeof document === 'undefined') return;
  const root = document.documentElement;

  const prefersDark =
    typeof window !== 'undefined' &&
    typeof window.matchMedia === 'function' &&
    window.matchMedia('(prefers-color-scheme: dark)').matches;

  const dark = t.mode === 'dark' || (t.mode === 'auto' && prefersDark);
  root.classList.toggle('dark', dark);

  const vars = dark ? { ...buildVars(t), ...buildDarkVars(t) } : buildVars(t);
  Object.entries(vars).forEach(([key, value]) => root.style.setProperty(key, value));

  root.dataset.mode = dark ? 'dark' : 'light';

  // 同步安卓浏览器地址栏 / 状态栏颜色
  const metaTheme = document.querySelector('meta[name="theme-color"]');
  if (metaTheme) {
    metaTheme.setAttribute(
      'content',
      dark ? '#1b1917' : oklch(0.694, 0.163 * t.chroma, t.hue)
    );
  }
}

/** 生成用于预览的小色板（预设按钮用） */
export function swatch(hue: number, chroma = 1): string {
  return oklch(0.7, 0.16 * chroma, hue);
}
