import { todayKey, addDays, monthKey, prevMonth, monthOf, weekDays } from './date';
import type { Todo, Reminder, Habit, Entry, StorageItem, Idea } from '@/types/workspace';

/** 连续打卡天数（以今天或昨天为终点） */
export function streakOf(records: string[]): number {
  const set = new Set(records);
  const today = todayKey();
  let cursor = set.has(today) ? today : addDays(today, -1);
  if (!set.has(cursor)) return 0;
  let n = 0;
  while (set.has(cursor)) {
    n++;
    cursor = addDays(cursor, -1);
  }
  return n;
}

/** 全部习惯的整体连续天数：当天所有习惯都打卡才算 */
export function globalStreak(habits: Habit[]): number {
  if (!habits.length) return 0;
  const today = todayKey();
  const allDone = (k: string) => habits.every((h) => h.records.includes(k));
  let cursor = allDone(today) ? today : addDays(today, -1);
  if (!allDone(cursor)) return 0;
  let n = 0;
  while (allDone(cursor)) {
    n++;
    cursor = addDays(cursor, -1);
  }
  return n;
}

/** 最长连续记录 */
export function longestStreak(records: string[]): number {
  if (!records.length) return 0;
  const sorted = [...records].sort();
  let best = 1;
  let cur = 1;
  for (let i = 1; i < sorted.length; i++) {
    if (Math.round((new Date(sorted[i]).getTime() - new Date(sorted[i - 1]).getTime()) / 86400000) === 1) {
      cur++;
      best = Math.max(best, cur);
    } else {
      cur = 1;
    }
  }
  return best;
}

export interface Stats {
  reminderCount: number;
  reminderOverdue: number;
  doneThisMonth: number;
  streak: number;
  monthExpense: number;
  monthIncome: number;
  monthExpenseDelta: number;
  pendingCount: number;
  todayTodos: number;
  todayHabitsDone: number;
  habitTotal: number;
}

export function computeStats(
  todos: Todo[],
  reminders: Reminder[],
  habits: Habit[],
  entries: Entry[],
  items: StorageItem[]
): Stats {
  const today = todayKey();
  const mk = monthKey();
  const pk = prevMonth(mk);

  const todayReminders = reminders.filter((r) => !r.done && r.date <= today);
  const reminderOverdue = reminders.filter((r) => !r.done && r.date < today).length;

  const doneThisMonth = todos.filter(
    (t) => t.done && t.doneAt && monthOf(t.doneAt.slice(0, 10)) === mk
  ).length;

  const exp = (m: string) =>
    entries.filter((e) => e.type === 'expense' && monthOf(e.date) === m).reduce((s, e) => s + e.amount, 0);
  const monthExpense = exp(mk);
  const prevExpense = exp(pk);
  const monthIncome = entries
    .filter((e) => e.type === 'income' && monthOf(e.date) === mk)
    .reduce((s, e) => s + e.amount, 0);

  const pendingTodos = todos.filter((t) => !t.done).length;
  const lentItems = items.filter((i) => i.lentTo).length;

  return {
    reminderCount: todayReminders.length,
    reminderOverdue,
    doneThisMonth,
    streak: globalStreak(habits),
    monthExpense,
    monthIncome,
    monthExpenseDelta: prevExpense > 0 ? ((monthExpense - prevExpense) / prevExpense) * 100 : 0,
    pendingCount: pendingTodos + todayReminders.length + lentItems,
    todayTodos: todos.filter((t) => !t.done && t.due === today).length,
    todayHabitsDone: habits.filter((h) => h.records.includes(today)).length,
    habitTotal: habits.length,
  };
}

/** 本周打卡热力：每个习惯本周 7 天状态 */
export function weekMatrix(habits: Habit[]) {
  const days = weekDays();
  return habits.map((h) => ({
    habit: h,
    cells: days.map((d) => h.records.includes(d)),
  }));
}

/** 本月支出按分类汇总 */
export function expenseByCategory(entries: Entry[], mKey: string) {
  const map = new Map<string, number>();
  entries
    .filter((e) => e.type === 'expense' && monthOf(e.date) === mKey)
    .forEach((e) => map.set(e.category, (map.get(e.category) || 0) + e.amount));
  return [...map.entries()].sort((a, b) => b[1] - a[1]);
}

/** 周复盘自动统计 */
export function weekAutoStats(
  todos: Todo[],
  habits: Habit[],
  entries: Entry[],
  ideas: Idea[],
  weekStart: string
) {
  const days = weekDays(weekStart);
  const inWeek = (k?: string) => !!k && days.includes(k);
  return {
    todosDone: todos.filter((t) => t.done && t.doneAt && inWeek(t.doneAt.slice(0, 10))).length,
    checkins: habits.reduce((s, h) => s + h.records.filter((d) => days.includes(d)).length, 0),
    expense: entries
      .filter((e) => e.type === 'expense' && days.includes(e.date))
      .reduce((s, e) => s + e.amount, 0),
    ideas: ideas.filter((i) => inWeek(i.createdAt.slice(0, 10))).length,
    habitRate: habits.length
      ? Math.round(
          (habits.reduce((s, h) => s + h.records.filter((d) => days.includes(d)).length, 0) /
            (habits.length * 7)) *
            100
        )
      : 0,
  };
}
