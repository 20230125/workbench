/**
 * 原生 App（Capacitor）适配
 * 在安卓原生壳里运行时：设置状态栏、隐藏启动画面、返回键处理。
 * 在普通浏览器中调用时全部静默跳过，不影响网页版与单文件版。
 */

import { Capacitor } from '@capacitor/core';

export const isNativeApp = () => {
  try {
    return Capacitor.isNativePlatform();
  } catch {
    return false;
  }
};

/** App 启动后调用：配置状态栏与启动图 */
export async function initNativeApp() {
  if (!isNativeApp()) return;

  try {
    const { StatusBar, Style } = await import('@capacitor/status-bar');
    // 深色文字（浅色背景），状态栏透明叠在页面上
    await StatusBar.setStyle({ style: Style.Dark });
    if (Capacitor.getPlatform() === 'android') {
      await StatusBar.setOverlaysWebView({ overlay: true });
    }
  } catch {
    /* 插件缺失时忽略 */
  }

  try {
    const { SplashScreen } = await import('@capacitor/splash-screen');
    await SplashScreen.hide();
  } catch {
    /* 忽略 */
  }
}

/**
 * 拦截安卓实体返回键：在子页面按返回应回到上一页，而不是直接退出 App。
 * 仅在首页按返回时才允许退出。
 */
export async function setupBackButton() {
  if (!isNativeApp()) return;
  if (Capacitor.getPlatform() !== 'android') return;

  try {
    const { App } = await import('@capacitor/app');

    App.addListener('backButton', ({ canGoBack }) => {
      const hash = window.location.hash;
      // 处于子页面：回退到首页
      if (hash && hash !== '#' && hash !== '#/' && hash !== '#/index') {
        window.history.back();
        return;
      }
      // 已在首页：退出应用
      if (!canGoBack) {
        App.exitApp();
      } else {
        window.history.back();
      }
    });
  } catch {
    /* 忽略 */
  }
}
