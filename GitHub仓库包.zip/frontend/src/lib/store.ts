import { useCallback, useEffect, useRef, useState } from 'react';

const PREFIX = 'wb.v1.';

function read<T>(key: string, fallback: T): T {
  try {
    const raw = localStorage.getItem(PREFIX + key);
    if (!raw) return fallback;
    return JSON.parse(raw) as T;
  } catch {
    return fallback;
  }
}

function write<T>(key: string, value: T) {
  try {
    localStorage.setItem(PREFIX + key, JSON.stringify(value));
    // 同页面内广播，让其它 hook 实例同步刷新
    window.dispatchEvent(new CustomEvent('wb:store', { detail: key }));
  } catch {
    /* quota exceeded — ignore */
  }
}

/** 通用 localStorage 状态 hook：跨组件实时同步 */
export function useLocalStore<T>(key: string, initial: T) {
  const [value, setValue] = useState<T>(() => read(key, initial));
  const keyRef = useRef(key);
  keyRef.current = key;

  useEffect(() => {
    const onChange = (e: Event) => {
      const detail = (e as CustomEvent<string>).detail;
      if (detail === keyRef.current) setValue(read(keyRef.current, initial));
    };
    const onStorage = (e: StorageEvent) => {
      if (e.key === PREFIX + keyRef.current) setValue(read(keyRef.current, initial));
    };
    window.addEventListener('wb:store', onChange);
    window.addEventListener('storage', onStorage);
    return () => {
      window.removeEventListener('wb:store', onChange);
      window.removeEventListener('storage', onStorage);
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  const update = useCallback((next: T | ((prev: T) => T)) => {
    setValue((prev) => {
      const resolved =
        typeof next === 'function' ? (next as (p: T) => T)(prev) : next;
      write(keyRef.current, resolved);
      return resolved;
    });
  }, []);

  return [value, update] as const;
}

export const uid = () =>
  Date.now().toString(36) + Math.random().toString(36).slice(2, 7);

export const store = { read, write, PREFIX };
