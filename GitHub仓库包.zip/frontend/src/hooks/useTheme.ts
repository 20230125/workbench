import { useEffect, useMemo } from 'react';
import { useLocalStore } from '@/lib/store';
import { DEFAULT_THEME, applyTheme, type ThemeState } from '@/lib/theme';

/**
 * 主题状态 hook。
 * 值存在 localStorage（wb.v1.theme），改动会立即写入 DOM 变量，
 * 因此任意页面修改后，所有页面/组件同步生效，无需刷新。
 */
export function useTheme() {
  const [raw, setTheme] = useLocalStore<ThemeState>('theme', DEFAULT_THEME);

  // 兼容旧数据 / 缺字段：合并默认值
  const theme = useMemo<ThemeState>(() => ({ ...DEFAULT_THEME, ...raw }), [raw]);

  useEffect(() => {
    applyTheme(theme);
  }, [theme]);

  // auto 模式下跟随系统切换
  useEffect(() => {
    if (theme.mode !== 'auto') return;
    const mq = window.matchMedia('(prefers-color-scheme: dark)');
    const onChange = () => applyTheme(theme);
    mq.addEventListener('change', onChange);
    return () => mq.removeEventListener('change', onChange);
  }, [theme]);

  const reset = () => setTheme(DEFAULT_THEME);

  return { theme, setTheme, reset };
}

/** 应用启动时立刻套用一次，避免首屏闪白 */
export function bootstrapTheme() {
  try {
    const raw = localStorage.getItem('wb.v1.theme');
    const parsed = raw ? { ...DEFAULT_THEME, ...JSON.parse(raw) } : DEFAULT_THEME;
    applyTheme(parsed);
  } catch {
    applyTheme(DEFAULT_THEME);
  }
}
