import { useLocalStore, uid } from '@/lib/store';
import { todayKey, monthOf, weekKeyOf } from '@/lib/date';
import type {
  Todo,
  Reminder,
  Habit,
  Entry,
  StorageItem,
  Idea,
  Reviews,
  Meta,
  EntryType,
} from '@/types/workspace';

/* ─────────── 待办 ─────────── */
export function useTodos() {
  const [todos, setTodos] = useLocalStore<Todo[]>('todos', []);
  return {
    todos,
    add: (title: string, priority: Todo['priority'] = 'mid', due?: string, note?: string) =>
      setTodos((p) => [
        {
          id: uid(),
          title: title.trim(),
          priority,
          due,
          note,
          done: false,
          createdAt: new Date().toISOString(),
        },
        ...p,
      ]),
    toggle: (id: string) =>
      setTodos((p) =>
        p.map((t) =>
          t.id === id
            ? { ...t, done: !t.done, doneAt: !t.done ? new Date().toISOString() : undefined }
            : t
        )
      ),
    remove: (id: string) => setTodos((p) => p.filter((t) => t.id !== id)),
    update: (id: string, patch: Partial<Todo>) =>
      setTodos((p) => p.map((t) => (t.id === id ? { ...t, ...patch } : t))),
  };
}

/* ─────────── 事项提醒 ─────────── */
export function useReminders() {
  const [reminders, setReminders] = useLocalStore<Reminder[]>('reminders', []);
  return {
    reminders,
    add: (r: Omit<Reminder, 'id' | 'createdAt' | 'done'>) =>
      setReminders((p) => [
        { ...r, id: uid(), done: false, createdAt: new Date().toISOString() },
        ...p,
      ]),
    toggle: (id: string) =>
      setReminders((p) => p.map((r) => (r.id === id ? { ...r, done: !r.done } : r))),
    remove: (id: string) =>
      setReminders((p) => p.filter((r) => r.id !== id)),
    update: (id: string, patch: Partial<Reminder>) =>
      setReminders((p) => p.map((r) => (r.id === id ? { ...r, ...patch } : r))),
  };
}

/* ─────────── 习惯打卡 ─────────── */
const HABIT_SEED: Habit[] = [
  { id: 'h1', name: '早起', emoji: '🌅', color: '#F97362', records: [], createdAt: '' },
  { id: 'h2', name: '阅读 30 分钟', emoji: '📖', color: '#7C9EE8', records: [], createdAt: '' },
  { id: 'h3', name: '运动', emoji: '🏃', color: '#4FB286', records: [], createdAt: '' },
  { id: 'h4', name: '喝够 8 杯水', emoji: '💧', color: '#5EB8D6', records: [], createdAt: '' },
  { id: 'h5', name: '早睡', emoji: '🌙', color: '#9A86D6', records: [], createdAt: '' },
];

export function useHabits() {
  const [habits, setHabits] = useLocalStore<Habit[]>(
    'habits',
    HABIT_SEED.map((h) => ({ ...h, createdAt: new Date().toISOString() }))
  );

  const check = (habitId: string, dateKey: string) =>
    setHabits((p) =>
      p.map((h) => {
        if (h.id !== habitId) return h;
        const has = h.records.includes(dateKey);
        return {
          ...h,
          records: has ? h.records.filter((d) => d !== dateKey) : [...h.records, dateKey],
        };
      })
    );

  return {
    habits,
    check,
    add: (name: string, emoji = '✨', color = '#F97362') =>
      setHabits((p) => [
        ...p,
        { id: uid(), name: name.trim(), emoji, color, records: [], createdAt: new Date().toISOString() },
      ]),
    remove: (id: string) => setHabits((p) => p.filter((h) => h.id !== id)),
    rename: (id: string, name: string) =>
      setHabits((p) => p.map((h) => (h.id === id ? { ...h, name } : h))),
  };
}

/* ─────────── 记账 ─────────── */
export function useLedger() {
  const [entries, setEntries] = useLocalStore<Entry[]>('ledger', []);
  return {
    entries,
    add: (e: { amount: number; type: EntryType; category: Entry['category']; note?: string; date: string }) =>
      setEntries((p) => [{ ...e, id: uid() }, ...p]),
    remove: (id: string) => setEntries((p) => p.filter((x) => x.id !== id)),
    entryOfMonth: (mKey: string) => entries.filter((e) => monthOf(e.date) === mKey),
  };
}

/* ─────────── 储物清单 ─────────── */
export function useStorage() {
  const [items, setItems] = useLocalStore<StorageItem[]>('storage', []);
  return {
    items,
    add: (i: Omit<StorageItem, 'id' | 'createdAt'>) =>
      setItems((p) => [...p, { ...i, id: uid(), createdAt: new Date().toISOString() }]),
    remove: (id: string) => setItems((p) => p.filter((x) => x.id !== id)),
    update: (id: string, patch: Partial<StorageItem>) =>
      setItems((p) => p.map((x) => (x.id === id ? { ...x, ...patch } : x))),
  };
}

/* ─────────── 灵感库 ─────────── */
export function useIdeas() {
  const [ideas, setIdeas] = useLocalStore<Idea[]>('ideas', []);
  return {
    ideas,
    add: (text: string, tag: Idea['tag'] = 'idea') =>
      setIdeas((p) => [
        { id: uid(), text: text.trim(), tag, starred: false, createdAt: new Date().toISOString() },
        ...p,
      ]),
    toggleStar: (id: string) =>
      setIdeas((p) => p.map((i) => (i.id === id ? { ...i, starred: !i.starred } : i))),
    remove: (id: string) => setIdeas((p) => p.filter((i) => i.id !== id)),
  };
}

/* ─────────── 周度复盘 ─────────── */
export function useReviews() {
  const [reviews, setReviews] = useLocalStore<Reviews>('reviews', {});
  const save = (weekKey: string, patch: Partial<Reviews[string]>) =>
    setReviews((p) => {
      const base: Reviews[string] = { good: '', bad: '', next: '', updatedAt: '' };
      const merged = { ...base, ...(p[weekKey] || {}), ...patch };
      merged.updatedAt = new Date().toISOString();
      return { ...p, [weekKey]: merged };
    });
  return { reviews, save, currentWeek: weekKeyOf() };
}

/* ─────────── 元信息 ─────────── */
export function useMeta() {
  const [meta, setMeta] = useLocalStore<Meta>('meta', { lastOpen: todayKey(), nickname: '我' });
  return { meta, setMeta };
}
