import { useMemo, useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Wallet, Plus, Trash2, TrendingUp, TrendingDown } from 'lucide-react';
import { PageHeader, Empty, SectionTitle, Segmented } from '@/components/workspace/UI';
import { Sheet, TextInput, Field, PrimaryButton } from '@/components/workspace/Sheet';
import { TabBar } from '@/components/workspace/TabBar';
import { useLedger } from '@/hooks/useWorkspace';
import { monthKey, prevMonth, formatMoney, relativeDay, todayKey, monthOf } from '@/lib/date';
import { expenseByCategory } from '@/lib/stats';
import type { EntryCategory, EntryType } from '@/types/workspace';

const CATS: { value: EntryCategory; label: string; emoji: string; color: string }[] = [
  { value: 'food', label: '餐饮', emoji: '🍜', color: 'oklch(0.68 0.16 45)' },
  { value: 'transport', label: '交通', emoji: '🚇', color: 'oklch(0.62 0.13 240)' },
  { value: 'shopping', label: '购物', emoji: '🛍', color: 'oklch(0.66 0.16 330)' },
  { value: 'home', label: '居家', emoji: '🏠', color: 'oklch(0.66 0.11 160)' },
  { value: 'fun', label: '娱乐', emoji: '🎬', color: 'oklch(0.68 0.15 295)' },
  { value: 'medical', label: '医疗', emoji: '💊', color: 'oklch(0.66 0.14 15)' },
  { value: 'study', label: '学习', emoji: '📘', color: 'oklch(0.62 0.13 255)' },
  { value: 'other', label: '其他', emoji: '📦', color: 'oklch(0.6 0.02 60)' },
];

export default function Ledger() {
  const { entries, add, remove } = useLedger();
  const [open, setOpen] = useState(false);
  const [amount, setAmount] = useState('');
  const [type, setType] = useState<EntryType>('expense');
  const [category, setCategory] = useState<EntryCategory>('food');
  const [note, setNote] = useState('');
  const [date, setDate] = useState(todayKey());

  const mk = monthKey();
  const monthEntries = useMemo(() => entries.filter((e) => monthOf(e.date) === mk), [entries, mk]);
  const expense = monthEntries.filter((e) => e.type === 'expense').reduce((s, e) => s + e.amount, 0);
  const income = monthEntries.filter((e) => e.type === 'income').reduce((s, e) => s + e.amount, 0);
  const prevExpense = entries
    .filter((e) => e.type === 'expense' && monthOf(e.date) === prevMonth(mk))
    .reduce((s, e) => s + e.amount, 0);

  const byCat = useMemo(() => expenseByCategory(entries, mk), [entries, mk]);
  const maxCat = byCat[0]?.[1] || 1;

  const grouped = useMemo(() => {
    const map = new Map<string, typeof monthEntries>();
    [...monthEntries]
      .sort((a, b) => b.date.localeCompare(a.date))
      .forEach((e) => {
        if (!map.has(e.date)) map.set(e.date, []);
        map.get(e.date)!.push(e);
      });
    return [...map.entries()];
  }, [monthEntries]);

  const submit = () => {
    const n = parseFloat(amount);
    if (!n || n <= 0) return;
    add({ amount: n, type, category, note: note || undefined, date });
    setAmount('');
    setNote('');
    setOpen(false);
  };

  const [y, m] = mk.split('-');

  return (
    <div className="phone-shell safe-bottom">
      <PageHeader title="记账本" subtitle={`${y} 年 ${Number(m)} 月 · 共 ${monthEntries.length} 笔`} />

      {/* 汇总 */}
      <div className="px-5 pt-3">
        <div
          className="relative overflow-hidden rounded-[var(--radius-lg)] p-4"
          style={{
            background:
              'linear-gradient(140deg, color-mix(in oklab, oklch(0.55 0.13 160) 92%, black), color-mix(in oklab, oklch(0.7 0.13 170) 65%, oklch(0.72 0.12 90)))',
            boxShadow: '0 12px 28px -14px oklch(0.5 0.12 165 / 0.55)',
          }}
        >
          <div className="pointer-events-none absolute -right-6 -bottom-8 size-28 rounded-full bg-white/12 blur-xl" />
          <p className="text-[10px] font-bold tracking-wide text-white/75">本月支出</p>
          <p className="mt-0.5 flex items-baseline gap-1 text-white">
            <span className="text-[length:var(--font-size-label)] font-bold">¥</span>
            <span className="tnum text-[2.1rem] font-extrabold leading-none">{formatMoney(expense)}</span>
          </p>
          <div className="mt-3 flex gap-4">
            <div>
              <p className="text-[9px] font-bold text-white/65">本月收入</p>
              <p className="tnum text-[length:var(--font-size-label)] font-extrabold text-white">
                ¥{formatMoney(income)}
              </p>
            </div>
            <div className="w-px bg-white/25" />
            <div>
              <p className="text-[9px] font-bold text-white/65">结余</p>
              <p className="tnum text-[length:var(--font-size-label)] font-extrabold text-white">
                ¥{formatMoney(income - expense)}
              </p>
            </div>
            <div className="w-px bg-white/25" />
            <div>
              <p className="text-[9px] font-bold text-white/65">较上月</p>
              <p className="flex items-center gap-0.5 text-[length:var(--font-size-label)] font-extrabold text-white">
                {prevExpense > 0 ? (
                  expense > prevExpense ? (
                    <>
                      <TrendingUp size={12} strokeWidth={3} />
                      {Math.round(((expense - prevExpense) / prevExpense) * 100)}%
                    </>
                  ) : (
                    <>
                      <TrendingDown size={12} strokeWidth={3} />
                      {Math.round(((prevExpense - expense) / prevExpense) * 100)}%
                    </>
                  )
                ) : (
                  '—'
                )}
              </p>
            </div>
          </div>
        </div>
      </div>

      {/* 分类占比 */}
      {byCat.length > 0 && (
        <div className="px-5 pt-5">
          <SectionTitle>支出构成</SectionTitle>
          <div className="rounded-[var(--radius-lg)] bg-card p-3.5 shadow-[var(--ds-shadow-sm)] border border-[color-mix(in_oklab,var(--border)_50%,transparent)]">
            <div className="space-y-2">
              {byCat.slice(0, 5).map(([cat, val]) => {
                const c = CATS.find((x) => x.value === cat)!;
                return (
                  <div key={cat} className="flex items-center gap-2">
                    <span className="w-[42px] shrink-0 text-[10px] font-bold text-foreground/80">
                      {c.emoji} {c.label}
                    </span>
                    <div className="h-2 flex-1 overflow-hidden rounded-full bg-secondary">
                      <motion.div
                        initial={{ width: 0 }}
                        animate={{ width: `${(val / maxCat) * 100}%` }}
                        transition={{ duration: 0.6, ease: [0.22, 0.9, 0.3, 1] }}
                        className="h-full rounded-full"
                        style={{ background: c.color }}
                      />
                    </div>
                    <span className="tnum w-[54px] shrink-0 text-right text-[10px] font-extrabold">
                      ¥{formatMoney(val)}
                    </span>
                  </div>
                );
              })}
            </div>
          </div>
        </div>
      )}

      {/* 明细 */}
      <div className="px-5 pt-5 pb-2">
        <SectionTitle>本月明细</SectionTitle>
        {grouped.length === 0 ? (
          <Empty
            icon={<Wallet size={26} strokeWidth={1.8} />}
            text="本月还没有记录"
            hint="记下第一笔，让每一分钱都有迹可循"
          />
        ) : (
          <div className="space-y-3">
            {grouped.map(([d, list]) => (
              <div key={d}>
                <div className="mb-1.5 flex items-center gap-2 px-1">
                  <span className="text-[length:var(--font-size-small)] font-extrabold">
                    {relativeDay(d)}
                  </span>
                  <span className="text-[10px] font-semibold text-muted-foreground">
                    {d.slice(5).replace('-', '/')}
                  </span>
                  <div className="h-px flex-1 bg-border/70" />
                  <span className="tnum text-[10px] font-bold text-muted-foreground">
                    ¥
                    {formatMoney(
                      list.filter((e) => e.type === 'expense').reduce((s, e) => s + e.amount, 0)
                    )}
                  </span>
                </div>
                <div className="overflow-hidden rounded-[var(--radius-lg)] bg-card shadow-[var(--ds-shadow-sm)] border border-[color-mix(in_oklab,var(--border)_50%,transparent)]">
                  <AnimatePresence initial={false}>
                    {list.map((e, i) => {
                      const c = CATS.find((x) => x.value === e.category)!;
                      return (
                        <motion.div
                          key={e.id}
                          layout
                          initial={{ opacity: 0 }}
                          animate={{ opacity: 1 }}
                          exit={{ opacity: 0, height: 0 }}
                          className="group flex items-center gap-2.5 px-3.5 py-2.5"
                          style={{
                            borderTop: i === 0 ? 'none' : '1px solid color-mix(in oklab, var(--border) 45%, transparent)',
                          }}
                        >
                          <span
                            className="flex size-8 shrink-0 items-center justify-center rounded-[10px] text-[14px]"
                            style={{ background: `color-mix(in oklab, ${c.color} 14%, transparent)` }}
                          >
                            {c.emoji}
                          </span>
                          <div className="min-w-0 flex-1">
                            <p className="truncate text-[length:var(--font-size-label)] font-bold">
                              {e.note || c.label}
                            </p>
                            <p className="text-[9px] font-semibold text-muted-foreground">{c.label}</p>
                          </div>
                          <span
                            className="tnum shrink-0 text-[length:var(--font-size-label)] font-extrabold"
                            style={{ color: e.type === 'expense' ? 'var(--theme-red)' : 'var(--theme-green)' }}
                          >
                            {e.type === 'expense' ? '-' : '+'}¥{formatMoney(e.amount)}
                          </span>
                          <button
                            onClick={() => remove(e.id)}
                            aria-label="删除"
                            className="flex size-6 shrink-0 items-center justify-center rounded-full text-muted-foreground/40 opacity-0 transition-all hover:text-destructive group-hover:opacity-100"
                          >
                            <Trash2 size={12} strokeWidth={2.6} />
                          </button>
                        </motion.div>
                      );
                    })}
                  </AnimatePresence>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>

      {/* 新增 */}
      <motion.button
        initial={{ scale: 0 }}
        animate={{ scale: 1 }}
        transition={{ type: 'spring', damping: 14, stiffness: 260 }}
        whileTap={{ scale: 0.9 }}
        onClick={() => setOpen(true)}
        aria-label="记一笔"
        className="fixed bottom-[calc(96px+env(safe-area-inset-bottom,0px))] right-[max(20px,calc(50%-220px))] z-30 flex size-14 items-center justify-center rounded-full text-primary-foreground shadow-[0_10px_24px_-6px_color-mix(in_oklab,var(--primary)_65%,transparent)]"
        style={{ background: 'var(--primary)' }}
      >
        <Plus size={26} strokeWidth={2.6} />
      </motion.button>

      <Sheet open={open} onClose={() => setOpen(false)} title="记一笔">
        <div className="mb-3">
          <Segmented
            value={type}
            onChange={setType}
            options={[
              { value: 'expense', label: '支出' },
              { value: 'income', label: '收入' },
            ]}
          />
        </div>
        <Field label="金额">
          <div className="relative">
            <span className="absolute left-3.5 top-1/2 -translate-y-1/2 text-[length:var(--font-size-body)] font-extrabold text-muted-foreground">
              ¥
            </span>
            <TextInput
              autoFocus
              type="number"
              inputMode="decimal"
              value={amount}
              onChange={(e) => setAmount(e.target.value)}
              placeholder="0.00"
              className="!pl-8 !text-[1.35rem] !font-extrabold tnum"
            />
          </div>
        </Field>
        <Field label="分类">
          <div className="grid grid-cols-4 gap-1.5">
            {CATS.map((c) => {
              const active = category === c.value;
              return (
                <button
                  key={c.value}
                  onClick={() => setCategory(c.value)}
                  className="press flex flex-col items-center gap-1 rounded-[12px] py-2 transition-all"
                  style={{
                    background: active ? `color-mix(in oklab, ${c.color} 16%, transparent)` : 'var(--secondary)',
                    outline: active ? `1.5px solid ${c.color}` : 'none',
                  }}
                >
                  <span className="text-[16px]">{c.emoji}</span>
                  <span
                    className="text-[9px] font-bold"
                    style={{ color: active ? c.color : 'var(--muted-foreground)' }}
                  >
                    {c.label}
                  </span>
                </button>
              );
            })}
          </div>
        </Field>
        <div className="grid grid-cols-2 gap-2">
          <Field label="日期">
            <TextInput type="date" value={date} onChange={(e) => setDate(e.target.value)} />
          </Field>
          <Field label="备注">
            <TextInput value={note} onChange={(e) => setNote(e.target.value)} placeholder="可选" />
          </Field>
        </div>
        <PrimaryButton onClick={submit} disabled={!amount || parseFloat(amount) <= 0}>
          保存记录
        </PrimaryButton>
      </Sheet>

      <TabBar />
    </div>
  );
}
