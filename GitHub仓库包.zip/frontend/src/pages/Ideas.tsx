import { useMemo, useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Lightbulb, Plus, Star, Trash2, ListPlus } from 'lucide-react';
import { PageHeader, Empty } from '@/components/workspace/UI';
import { Sheet, TextArea, Field, ChipGroup, PrimaryButton } from '@/components/workspace/Sheet';
import { TabBar } from '@/components/workspace/TabBar';
import { useIdeas, useTodos } from '@/hooks/useWorkspace';
import { relativeDay } from '@/lib/date';
import type { IdeaTag } from '@/types/workspace';

const TAGS: { value: IdeaTag; label: string; color: string }[] = [
  { value: 'idea', label: '💡 想法', color: 'oklch(0.68 0.15 85)' },
  { value: 'read', label: '📖 待读', color: 'oklch(0.62 0.13 250)' },
  { value: 'watch', label: '🎬 待看', color: 'oklch(0.66 0.15 300)' },
  { value: 'collect', label: '⭐ 收藏', color: 'oklch(0.66 0.13 45)' },
];

export default function Ideas() {
  const { ideas, add, toggleStar, remove } = useIdeas();
  const { add: addTodo } = useTodos();
  const [open, setOpen] = useState(false);
  const [text, setText] = useState('');
  const [tag, setTag] = useState<IdeaTag>('idea');
  const [filter, setFilter] = useState<'all' | IdeaTag>('all');

  const list = useMemo(() => {
    const arr = filter === 'all' ? ideas : ideas.filter((i) => i.tag === filter);
    return [...arr].sort((a, b) => Number(b.starred) - Number(a.starred) || b.createdAt.localeCompare(a.createdAt));
  }, [ideas, filter]);

  const submit = () => {
    if (!text.trim()) return;
    add(text, tag);
    setText('');
    setOpen(false);
  };

  return (
    <div className="phone-shell safe-bottom">
      <PageHeader title="灵感库" subtitle={`共 ${ideas.length} 条 · 收藏 ${ideas.filter((i) => i.starred).length} 条`} />

      {/* 筛选 */}
      <div className="flex gap-1.5 overflow-x-auto px-5 pt-3">
        {[{ value: 'all' as const, label: '全部', color: 'var(--primary)' }, ...TAGS].map((t) => {
          const active = filter === t.value;
          return (
            <button
              key={t.value}
              onClick={() => setFilter(t.value as typeof filter)}
              className="shrink-0 rounded-full px-3 py-1.5 text-[length:var(--font-size-small)] font-bold transition-colors"
              style={
                active
                  ? { background: 'var(--primary)', color: 'var(--primary-foreground)' }
                  : { background: 'var(--secondary)', color: 'var(--muted-foreground)' }
              }
            >
              {t.label}
            </button>
          );
        })}
      </div>

      {/* 列表 */}
      <div className="px-5 pt-4">
        {list.length === 0 ? (
          <Empty
            icon={<Lightbulb size={26} strokeWidth={1.8} />}
            text="灵感库还是空的"
            hint="任何一闪而过的念头，都值得被记下来"
          />
        ) : (
          <div className="space-y-2">
            <AnimatePresence initial={false}>
              {list.map((it, i) => {
                const t = TAGS.find((x) => x.value === it.tag)!;
                return (
                  <motion.div
                    key={it.id}
                    layout
                    initial={{ opacity: 0, y: 10 }}
                    animate={{ opacity: 1, y: 0 }}
                    exit={{ opacity: 0, scale: 0.96, height: 0, marginBottom: 0 }}
                    transition={{ duration: 0.22, delay: Math.min(i * 0.03, 0.2) }}
                    className="group relative overflow-hidden rounded-[var(--radius-lg)] bg-card p-3.5 shadow-[var(--ds-shadow-sm)] border border-[color-mix(in_oklab,var(--border)_50%,transparent)]"
                  >
                    <div
                      className="absolute inset-y-0 left-0 w-[3px]"
                      style={{ background: t.color }}
                    />
                    <div className="flex items-start gap-2">
                      <div className="min-w-0 flex-1 pl-1">
                        <p className="whitespace-pre-wrap text-[length:var(--font-size-label)] font-semibold leading-relaxed">
                          {it.text}
                        </p>
                        <div className="mt-2 flex items-center gap-2">
                          <span
                            className="rounded-full px-1.5 py-0.5 text-[9px] font-extrabold"
                            style={{
                              background: `color-mix(in oklab, ${t.color} 15%, transparent)`,
                              color: t.color,
                            }}
                          >
                            {t.label}
                          </span>
                          <span className="text-[9px] font-semibold text-muted-foreground">
                            {relativeDay(it.createdAt.slice(0, 10))}
                          </span>
                        </div>
                      </div>
                      <div className="flex shrink-0 flex-col gap-1">
                        <button
                          onClick={() => toggleStar(it.id)}
                          aria-label="收藏"
                          className="press flex size-7 items-center justify-center rounded-full transition-colors"
                          style={{
                            color: it.starred ? 'oklch(0.78 0.16 85)' : 'var(--muted-foreground)',
                            background: it.starred
                              ? 'color-mix(in oklab, oklch(0.78 0.16 85) 14%, transparent)'
                              : 'transparent',
                          }}
                        >
                          <Star size={13} strokeWidth={2.4} fill={it.starred ? 'currentColor' : 'none'} />
                        </button>
                        <button
                          onClick={() => {
                            addTodo(it.text, 'mid');
                            remove(it.id);
                          }}
                          aria-label="转为待办"
                          className="flex size-7 items-center justify-center rounded-full text-muted-foreground/50 transition-colors hover:text-primary"
                        >
                          <ListPlus size={13} strokeWidth={2.4} />
                        </button>
                        <button
                          onClick={() => remove(it.id)}
                          aria-label="删除"
                          className="flex size-7 items-center justify-center rounded-full text-muted-foreground/40 opacity-0 transition-all hover:text-destructive group-hover:opacity-100"
                        >
                          <Trash2 size={13} strokeWidth={2.4} />
                        </button>
                      </div>
                    </div>
                  </motion.div>
                );
              })}
            </AnimatePresence>
          </div>
        )}
      </div>

      <motion.button
        initial={{ scale: 0 }}
        animate={{ scale: 1 }}
        transition={{ type: 'spring', damping: 14, stiffness: 260 }}
        whileTap={{ scale: 0.9 }}
        onClick={() => setOpen(true)}
        aria-label="记录灵感"
        className="fixed bottom-[calc(96px+env(safe-area-inset-bottom,0px))] right-[max(20px,calc(50%-220px))] z-30 flex size-14 items-center justify-center rounded-full text-primary-foreground shadow-[0_10px_24px_-6px_color-mix(in_oklab,var(--primary)_65%,transparent)]"
        style={{ background: 'var(--primary)' }}
      >
        <Plus size={26} strokeWidth={2.6} />
      </motion.button>

      <Sheet open={open} onClose={() => setOpen(false)} title="记录灵感">
        <Field label="写点什么">
          <TextArea
            autoFocus
            rows={4}
            value={text}
            onChange={(e) => setText(e.target.value)}
            placeholder="一个想法、一本书、一部电影…"
          />
        </Field>
        <Field label="标签">
          <ChipGroup value={tag} onChange={setTag} options={TAGS} />
        </Field>
        <PrimaryButton onClick={submit} disabled={!text.trim()}>
          保存灵感
        </PrimaryButton>
      </Sheet>

      <TabBar />
    </div>
  );
}
