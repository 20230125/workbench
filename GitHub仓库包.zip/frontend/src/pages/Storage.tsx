import { useMemo, useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Boxes, Plus, Trash2, Search, MapPin, HandHelping, Check } from 'lucide-react';
import { PageHeader, Empty, Tag } from '@/components/workspace/UI';
import { Sheet, TextInput, Field, ChipGroup, PrimaryButton } from '@/components/workspace/Sheet';
import { TabBar } from '@/components/workspace/TabBar';
import { useStorage } from '@/hooks/useWorkspace';

const ROOMS = [
  { value: '客厅', label: '客厅', color: 'oklch(0.66 0.13 45)' },
  { value: '卧室', label: '卧室', color: 'oklch(0.64 0.13 300)' },
  { value: '厨房', label: '厨房', color: 'oklch(0.66 0.13 120)' },
  { value: '书房', label: '书房', color: 'oklch(0.62 0.13 250)' },
  { value: '卫生间', label: '卫生间', color: 'oklch(0.64 0.11 200)' },
  { value: '储物间', label: '储物间', color: 'oklch(0.62 0.02 60)' },
];

export default function Storage() {
  const { items, add, remove, update } = useStorage();
  const [q, setQ] = useState('');
  const [room, setRoom] = useState<string>('all');
  const [open, setOpen] = useState(false);
  const [name, setName] = useState('');
  const [category, setCategory] = useState('客厅');
  const [location, setLocation] = useState('');
  const [qty, setQty] = useState('1');
  const [note, setNote] = useState('');

  const filtered = useMemo(() => {
    const kw = q.trim().toLowerCase();
    return items
      .filter((i) => (room === 'all' ? true : i.category === room))
      .filter((i) =>
        kw
          ? i.name.toLowerCase().includes(kw) ||
            i.location.toLowerCase().includes(kw) ||
            (i.note || '').toLowerCase().includes(kw)
          : true
      );
  }, [items, q, room]);

  const grouped = useMemo(() => {
    const map = new Map<string, typeof filtered>();
    filtered.forEach((i) => {
      if (!map.has(i.category)) map.set(i.category, []);
      map.get(i.category)!.push(i);
    });
    return [...map.entries()];
  }, [filtered]);

  const submit = () => {
    if (!name.trim() || !location.trim()) return;
    add({
      name: name.trim(),
      category,
      location: location.trim(),
      qty: Number(qty) || 1,
      note: note || undefined,
    });
    setName('');
    setLocation('');
    setQty('1');
    setNote('');
    setOpen(false);
  };

  return (
    <div className="phone-shell safe-bottom">
      <PageHeader title="储物清单" subtitle={`共 ${items.length} 件物品 · 借出 ${items.filter((i) => i.lentTo).length} 件`} />

      {/* 搜索 */}
      <div className="px-5 pt-3">
        <div className="relative">
          <TextInput
            value={q}
            onChange={(e) => setQ(e.target.value)}
            placeholder="搜索物品名称或存放位置…"
            className="!bg-card !pl-9 !py-2.5 shadow-[var(--ds-shadow-sm)]"
          />
          <Search
            size={15}
            className="pointer-events-none absolute left-3 top-1/2 -translate-y-1/2 text-muted-foreground"
            strokeWidth={2.6}
          />
        </div>
      </div>

      {/* 房间筛选 */}
      <div className="flex gap-1.5 overflow-x-auto px-5 pt-3">
        {[{ value: 'all', label: '全部', color: 'var(--primary)' }, ...ROOMS].map((r) => {
          const active = room === r.value;
          const n = r.value === 'all' ? items.length : items.filter((i) => i.category === r.value).length;
          return (
            <button
              key={r.value}
              onClick={() => setRoom(r.value)}
              className="shrink-0 rounded-full px-3 py-1.5 text-[length:var(--font-size-small)] font-bold transition-colors"
              style={
                active
                  ? { background: 'var(--primary)', color: 'var(--primary-foreground)' }
                  : { background: 'var(--secondary)', color: 'var(--muted-foreground)' }
              }
            >
              {r.label}
              <span className="ml-1 opacity-70">{n}</span>
            </button>
          );
        })}
      </div>

      {/* 列表 */}
      <div className="px-5 pt-4">
        {grouped.length === 0 ? (
          <Empty
            icon={<Boxes size={26} strokeWidth={1.8} />}
            text={q ? '没有找到相关物品' : '还没有记录物品'}
            hint="把东西的位置记下来，再也不用翻箱倒柜"
          />
        ) : (
          <div className="space-y-4">
            {grouped.map(([roomName, list]) => (
              <div key={roomName}>
                <div className="mb-1.5 flex items-center gap-2 px-1">
                  <span className="text-[length:var(--font-size-small)] font-extrabold">{roomName}</span>
                  <div className="h-px flex-1 bg-border/70" />
                  <span className="text-[10px] font-bold text-muted-foreground">{list.length} 件</span>
                </div>
                <div className="space-y-2">
                  <AnimatePresence initial={false}>
                    {list.map((it) => {
                      const c = ROOMS.find((r) => r.value === it.category);
                      return (
                        <motion.div
                          key={it.id}
                          layout
                          initial={{ opacity: 0, y: 8 }}
                          animate={{ opacity: 1, y: 0 }}
                          exit={{ opacity: 0, height: 0, marginBottom: 0 }}
                          className="group rounded-[var(--radius-lg)] bg-card p-3.5 shadow-[var(--ds-shadow-sm)] border border-[color-mix(in_oklab,var(--border)_50%,transparent)]"
                        >
                          <div className="flex items-start gap-2.5">
                            <span
                              className="flex size-9 shrink-0 items-center justify-center rounded-[12px] text-[15px]"
                              style={{ background: `color-mix(in oklab, ${c?.color || 'var(--primary)'} 14%, transparent)` }}
                            >
                              📦
                            </span>
                            <div className="min-w-0 flex-1">
                              <div className="flex items-center gap-1.5">
                                <p className="truncate text-[length:var(--font-size-label)] font-bold">
                                  {it.name}
                                </p>
                                <Tag>{`×${it.qty}`}</Tag>
                                {it.lentTo && <Tag color="oklch(0.66 0.16 45)">借出中</Tag>}
                              </div>
                              <p className="mt-1 flex items-center gap-1 text-[10px] font-semibold text-muted-foreground">
                                <MapPin size={10} strokeWidth={2.8} />
                                {it.location}
                              </p>
                              {it.note && (
                                <p className="mt-1 text-[10px] leading-relaxed text-muted-foreground/80">
                                  {it.note}
                                </p>
                              )}
                              {it.lentTo && (
                                <p className="mt-1 text-[10px] font-bold text-[oklch(0.6_0.15_45)]">
                                  借给 {it.lentTo}
                                  {it.lentAt ? ` · ${it.lentAt}` : ''}
                                </p>
                              )}
                            </div>
                            <div className="flex shrink-0 flex-col gap-1">
                              <button
                                onClick={() =>
                                  it.lentTo
                                    ? update(it.id, { lentTo: undefined, lentAt: undefined })
                                    : update(it.id, { lentTo: '朋友', lentAt: new Date().toISOString().slice(0, 10) })
                                }
                                aria-label={it.lentTo ? '标记归还' : '标记借出'}
                                className="press flex size-7 items-center justify-center rounded-full transition-colors"
                                style={{
                                  background: it.lentTo ? 'color-mix(in oklab, var(--theme-green) 15%, transparent)' : 'var(--secondary)',
                                  color: it.lentTo ? 'var(--theme-green)' : 'var(--muted-foreground)',
                                }}
                              >
                                {it.lentTo ? <Check size={13} strokeWidth={3} /> : <HandHelping size={13} strokeWidth={2.4} />}
                              </button>
                              <button
                                onClick={() => remove(it.id)}
                                aria-label="删除"
                                className="flex size-7 items-center justify-center rounded-full text-muted-foreground/40 transition-colors hover:bg-destructive/10 hover:text-destructive"
                              >
                                <Trash2 size={13} strokeWidth={2.4} />
                              </button>
                            </div>
                          </div>
                        </motion.div>
                      );
                    })}
                  </AnimatePresence>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>

      <motion.button
        initial={{ scale: 0 }}
        animate={{ scale: 1 }}
        transition={{ type: 'spring', damping: 14, stiffness: 260 }}
        whileTap={{ scale: 0.9 }}
        onClick={() => setOpen(true)}
        aria-label="新增物品"
        className="fixed bottom-[calc(96px+env(safe-area-inset-bottom,0px))] right-[max(20px,calc(50%-220px))] z-30 flex size-14 items-center justify-center rounded-full text-primary-foreground shadow-[0_10px_24px_-6px_color-mix(in_oklab,var(--primary)_65%,transparent)]"
        style={{ background: 'var(--primary)' }}
      >
        <Plus size={26} strokeWidth={2.6} />
      </motion.button>

      <Sheet open={open} onClose={() => setOpen(false)} title="新增物品">
        <Field label="物品名称">
          <TextInput autoFocus value={name} onChange={(e) => setName(e.target.value)} placeholder="例如：充电宝" />
        </Field>
        <Field label="存放位置">
          <TextInput
            value={location}
            onChange={(e) => setLocation(e.target.value)}
            placeholder="例如：书桌第二层抽屉"
          />
        </Field>
        <Field label="区域">
          <ChipGroup value={category} onChange={setCategory} options={ROOMS} />
        </Field>
        <div className="grid grid-cols-2 gap-2">
          <Field label="数量">
            <TextInput type="number" value={qty} onChange={(e) => setQty(e.target.value)} />
          </Field>
          <Field label="备注">
            <TextInput value={note} onChange={(e) => setNote(e.target.value)} placeholder="可选" />
          </Field>
        </div>
        <PrimaryButton onClick={submit} disabled={!name.trim() || !location.trim()}>
          保存物品
        </PrimaryButton>
      </Sheet>

      <TabBar />
    </div>
  );
}
