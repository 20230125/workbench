import { useMemo, useState } from 'react';
import { motion } from 'framer-motion';
import { Flame, Trophy, Plus, Trash2, Check } from 'lucide-react';
import { PageHeader, Empty, SectionTitle } from '@/components/workspace/UI';
import { Sheet, TextInput, Field, PrimaryButton } from '@/components/workspace/Sheet';
import { TabBar } from '@/components/workspace/TabBar';
import { useHabits } from '@/hooks/useWorkspace';
import { streakOf, longestStreak } from '@/lib/stats';
import { todayKey, weekDays, pad2 } from '@/lib/date';

const EMOJIS = ['🌅', '📖', '🏃', '💧', '🌙', '🧘', '✍️', '🎸', '🥗', '💪', '🧹', '☀️'];
const COLORS = ['#F97362', '#7C9EE8', '#4FB286', '#5EB8D6', '#9A86D6', '#E8A33D', '#D96B9A', '#5BA88F'];
const WEEK_SHORT = ['一', '二', '三', '四', '五', '六', '日'];

export default function Habits() {
  const { habits, check, add, remove } = useHabits();
  const [open, setOpen] = useState(false);
  const [name, setName] = useState('');
  const [emoji, setEmoji] = useState(EMOJIS[0]);
  const [color, setColor] = useState(COLORS[0]);

  const today = todayKey();
  const days = useMemo(() => weekDays(), []);

  const allDone = habits.length > 0 && habits.every((h) => h.records.includes(today));
  const doneCount = habits.filter((h) => h.records.includes(today)).length;
  const rate = habits.length ? Math.round((doneCount / habits.length) * 100) : 0;

  const totalCheckins = habits.reduce((s, h) => s + h.records.length, 0);
  const bestStreak = habits.reduce((m, h) => Math.max(m, longestStreak(h.records)), 0);

  // 近 30 天热力图数据
  const heat = useMemo(() => {
    const arr: { date: string; n: number }[] = [];
    const base = new Date();
    for (let i = 29; i >= 0; i--) {
      const d = new Date(base);
      d.setDate(d.getDate() - i);
      const k = `${d.getFullYear()}-${pad2(d.getMonth() + 1)}-${pad2(d.getDate())}`;
      arr.push({ date: k, n: habits.filter((h) => h.records.includes(k)).length });
    }
    return arr;
  }, [habits]);

  const submit = () => {
    if (!name.trim()) return;
    add(name, emoji, color);
    setName('');
    setOpen(false);
  };

  return (
    <div className="phone-shell safe-bottom">
      <PageHeader title="习惯打卡" subtitle={`今日 ${doneCount}/${habits.length} · 完成度 ${rate}%`} back={false} />

      {/* 总览 */}
      <div className="px-5 pt-3">
        <div
          className="relative overflow-hidden rounded-[var(--radius-lg)] p-4"
          style={{
            background:
              'linear-gradient(135deg, color-mix(in oklab, var(--primary) 90%, black), color-mix(in oklab, var(--primary) 55%, oklch(0.82 0.14 60)))',
            boxShadow: '0 12px 28px -12px color-mix(in oklab, var(--primary) 70%, transparent)',
          }}
        >
          <div className="pointer-events-none absolute -right-8 -top-8 size-28 rounded-full bg-white/15 blur-xl" />
          <div className="relative flex items-center justify-between">
            <div>
              <p className="text-[10px] font-bold tracking-wide text-white/75">今日完成度</p>
              <p className="mt-0.5 flex items-baseline gap-1 text-white">
                <span className="tnum text-[2rem] font-extrabold leading-none">{rate}</span>
                <span className="text-[length:var(--font-size-label)] font-bold">%</span>
              </p>
              <p className="mt-1.5 text-[10px] font-semibold text-white/80">
                {allDone ? '今天的习惯全部完成，太棒了！' : `还有 ${habits.length - doneCount} 个习惯等你`}
              </p>
            </div>
            <div className="flex gap-3 text-white">
              <div className="text-center">
                <Trophy size={16} className="mx-auto mb-0.5 opacity-90" strokeWidth={2.4} />
                <p className="tnum text-[length:var(--font-size-label)] font-extrabold">{bestStreak}</p>
                <p className="text-[9px] font-semibold opacity-75">最长连续</p>
              </div>
              <div className="w-px bg-white/25" />
              <div className="text-center">
                <Flame size={16} className="mx-auto mb-0.5 opacity-90" strokeWidth={2.4} />
                <p className="tnum text-[length:var(--font-size-label)] font-extrabold">{totalCheckins}</p>
                <p className="text-[9px] font-semibold opacity-75">累计打卡</p>
              </div>
            </div>
          </div>
          {/* 进度条 */}
          <div className="relative mt-3 h-1.5 overflow-hidden rounded-full bg-white/25">
            <motion.div
              className="h-full rounded-full bg-white"
              initial={{ width: 0 }}
              animate={{ width: `${rate}%` }}
              transition={{ duration: 0.7, ease: [0.22, 0.9, 0.3, 1] }}
            />
          </div>
        </div>
      </div>

      {/* 习惯列表 */}
      <div className="px-5 pt-5">
        <SectionTitle hint="近 7 天可补卡">我的习惯</SectionTitle>
        {habits.length === 0 ? (
          <Empty icon={<Flame size={26} strokeWidth={1.8} />} text="还没有习惯" hint="添加第一个习惯，开始你的坚持" />
        ) : (
          <div className="space-y-2">
            {habits.map((h, idx) => {
              const streak = streakOf(h.records);
              const checkedToday = h.records.includes(today);
              return (
                <motion.div
                  key={h.id}
                  initial={{ opacity: 0, y: 10 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: idx * 0.04 }}
                  className="rounded-[var(--radius-lg)] bg-card p-3.5 shadow-[var(--ds-shadow-sm)] border border-[color-mix(in_oklab,var(--border)_50%,transparent)]"
                >
                  <div className="flex items-center gap-2.5">
                    <span
                      className="flex size-10 shrink-0 items-center justify-center rounded-[13px] text-[19px]"
                      style={{ background: `color-mix(in oklab, ${h.color} 15%, transparent)` }}
                    >
                      {h.emoji}
                    </span>
                    <div className="min-w-0 flex-1">
                      <p className="truncate text-[length:var(--font-size-label)] font-bold">{h.name}</p>
                      <p className="mt-0.5 flex items-center gap-1 text-[10px] font-semibold text-muted-foreground">
                        {streak > 0 ? (
                          <>
                            <Flame size={10} style={{ color: h.color }} strokeWidth={3} />
                            连续 {streak} 天
                          </>
                        ) : (
                          '今天开始也不晚'
                        )}
                      </p>
                    </div>
                    <button
                      onClick={() => check(h.id, today)}
                      aria-label={checkedToday ? '取消打卡' : '打卡'}
                      className="press flex size-9 shrink-0 items-center justify-center rounded-full transition-all"
                      style={{
                        background: checkedToday ? h.color : `color-mix(in oklab, ${h.color} 12%, transparent)`,
                        color: checkedToday ? '#fff' : h.color,
                      }}
                    >
                      {checkedToday ? (
                        <Check size={17} strokeWidth={3.4} className="pop-in" />
                      ) : (
                        <Flame size={16} strokeWidth={2.6} />
                      )}
                    </button>
                    <button
                      onClick={() => remove(h.id)}
                      aria-label="删除习惯"
                      className="flex size-7 shrink-0 items-center justify-center rounded-full text-muted-foreground/40 transition-colors hover:bg-destructive/10 hover:text-destructive"
                    >
                      <Trash2 size={13} strokeWidth={2.4} />
                    </button>
                  </div>

                  {/* 近 7 天 */}
                  <div className="mt-2.5 flex items-center justify-between pl-1 pr-1">
                    {days.map((d, i) => {
                      const on = h.records.includes(d);
                      const isToday = d === today;
                      const future = d > today;
                      return (
                        <button
                          key={d}
                          disabled={future}
                          onClick={() => check(h.id, d)}
                          aria-label={`${d} 打卡`}
                          className="flex flex-col items-center gap-1 disabled:opacity-30"
                        >
                          <span
                            className="text-[8px] font-bold"
                            style={{ color: isToday ? h.color : 'var(--muted-foreground)' }}
                          >
                            {WEEK_SHORT[i]}
                          </span>
                          <span
                            className="flex size-[19px] items-center justify-center rounded-[6px] transition-all"
                            style={{
                              background: on ? h.color : 'var(--secondary)',
                              outline: isToday ? `1.5px solid ${h.color}` : 'none',
                              outlineOffset: 1,
                            }}
                          >
                            {on && <Check size={11} color="#fff" strokeWidth={4} />}
                          </span>
                        </button>
                      );
                    })}
                  </div>
                </motion.div>
              );
            })}
          </div>
        )}
      </div>

      {/* 近 30 天热力 */}
      <div className="px-5 pt-6 pb-2">
        <SectionTitle>近 30 天打卡热力</SectionTitle>
        <div className="rounded-[var(--radius-lg)] bg-card p-3.5 shadow-[var(--ds-shadow-sm)] border border-[color-mix(in_oklab,var(--border)_50%,transparent)]">
          <div className="grid grid-cols-10 gap-1.5">
            {heat.map((c) => {
              const ratio = habits.length ? c.n / habits.length : 0;
              return (
                <div
                  key={c.date}
                  title={`${c.date} · ${c.n} 个习惯`}
                  className="aspect-square rounded-[5px] transition-transform hover:scale-110"
                  style={{
                    background:
                      c.n === 0
                        ? 'var(--secondary)'
                        : `color-mix(in oklab, var(--primary) ${Math.max(22, Math.round(ratio * 100))}%, var(--secondary))`,
                  }}
                />
              );
            })}
          </div>
          <div className="mt-2.5 flex items-center justify-end gap-1">
            <span className="text-[9px] font-semibold text-muted-foreground">少</span>
            {[0.15, 0.4, 0.65, 0.9, 1].map((o) => (
              <span
                key={o}
                className="size-2.5 rounded-[3px]"
                style={{ background: `color-mix(in oklab, var(--primary) ${o * 100}%, var(--secondary))` }}
              />
            ))}
            <span className="text-[9px] font-semibold text-muted-foreground">多</span>
          </div>
        </div>
      </div>

      {/* 新增 */}
      <motion.button
        initial={{ scale: 0 }}
        animate={{ scale: 1 }}
        transition={{ type: 'spring', damping: 14, stiffness: 260 }}
        whileTap={{ scale: 0.9 }}
        onClick={() => setOpen(true)}
        aria-label="新增习惯"
        className="fixed bottom-[calc(96px+env(safe-area-inset-bottom,0px))] right-[max(20px,calc(50%-220px))] z-30 flex size-14 items-center justify-center rounded-full text-primary-foreground shadow-[0_10px_24px_-6px_color-mix(in_oklab,var(--primary)_65%,transparent)]"
        style={{ background: 'var(--primary)' }}
      >
        <Plus size={26} strokeWidth={2.6} />
      </motion.button>

      <Sheet open={open} onClose={() => setOpen(false)} title="新增习惯">
        <Field label="习惯名称">
          <TextInput
            autoFocus
            value={name}
            onChange={(e) => setName(e.target.value)}
            placeholder="例如：冥想 10 分钟"
          />
        </Field>
        <Field label="图标">
          <div className="flex flex-wrap gap-1.5">
            {EMOJIS.map((e) => (
              <button
                key={e}
                onClick={() => setEmoji(e)}
                className="press flex size-9 items-center justify-center rounded-[11px] text-[17px] transition-all"
                style={{
                  background: emoji === e ? 'color-mix(in oklab, var(--primary) 16%, transparent)' : 'var(--secondary)',
                  outline: emoji === e ? '1.5px solid var(--primary)' : 'none',
                }}
              >
                {e}
              </button>
            ))}
          </div>
        </Field>
        <Field label="颜色">
          <div className="flex flex-wrap gap-2">
            {COLORS.map((c) => (
              <button
                key={c}
                onClick={() => setColor(c)}
                aria-label={`颜色 ${c}`}
                className="press size-7 rounded-full transition-transform"
                style={{
                  background: c,
                  outline: color === c ? `2px solid ${c}` : 'none',
                  outlineOffset: 2,
                }}
              />
            ))}
          </div>
        </Field>
        <PrimaryButton onClick={submit} disabled={!name.trim()}>
          添加习惯
        </PrimaryButton>
      </Sheet>

      <TabBar />
    </div>
  );
}
