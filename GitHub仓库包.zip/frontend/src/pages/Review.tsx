import { useMemo, useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import {
  NotebookPen,
  ChevronLeft,
  ChevronRight,
  CheckCircle2,
  Flame,
  Wallet,
  Lightbulb,
  Sparkles,
} from 'lucide-react';
import { PageHeader, SectionTitle, Card } from '@/components/workspace/UI';
import { TabBar } from '@/components/workspace/TabBar';
import { useReviews, useTodos, useHabits, useLedger, useIdeas } from '@/hooks/useWorkspace';
import { weekAutoStats } from '@/lib/stats';
import { weekDays, weekStartKey, addDays, formatDateCn, formatMoney } from '@/lib/date';

const AREAS = [
  { key: 'good' as const, label: '做得好的地方', hint: '这周哪件事让你觉得「还不错」？', color: 'oklch(0.64 0.14 152)' },
  { key: 'bad' as const, label: '可以改进的', hint: '哪里卡住了？下次怎么绕开？', color: 'oklch(0.68 0.14 55)' },
  { key: 'next' as const, label: '下周目标', hint: '写 1-3 件最重要的事', color: 'oklch(0.62 0.13 260)' },
];

export default function Review() {
  const { reviews, save } = useReviews();
  const { todos } = useTodos();
  const { habits } = useHabits();
  const { entries } = useLedger();
  const { ideas } = useIdeas();

  const thisWeek = weekStartKey();
  const [offset, setOffset] = useState(0);
  const weekKey = useMemo(() => addDays(thisWeek, offset * 7), [thisWeek, offset]);
  const days = useMemo(() => weekDays(weekKey), [weekKey]);

  const record = reviews[weekKey] || { good: '', bad: '', next: '', updatedAt: '' };
  const [draft, setDraft] = useState({ good: record.good, bad: record.bad, next: record.next });
  const [saved, setSaved] = useState(false);

  useEffect(() => {
    setDraft({ good: record.good, bad: record.bad, next: record.next });
    setSaved(false);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [weekKey]);

  const auto = useMemo(
    () => weekAutoStats(todos, habits, entries, ideas, weekKey),
    [todos, habits, entries, ideas, weekKey]
  );

  const isFuture = weekKey > thisWeek;

  const stats = [
    { icon: <CheckCircle2 size={15} strokeWidth={2.6} />, label: '完成待办', value: String(auto.todosDone), unit: '项', color: 'oklch(0.62 0.13 250)' },
    { icon: <Flame size={15} strokeWidth={2.6} />, label: '打卡次数', value: String(auto.checkins), unit: '次', color: 'var(--primary)' },
    { icon: <Sparkles size={15} strokeWidth={2.6} />, label: '打卡率', value: String(auto.habitRate), unit: '%', color: 'oklch(0.72 0.14 85)' },
    { icon: <Wallet size={15} strokeWidth={2.6} />, label: '本周支出', value: '¥' + formatMoney(auto.expense), unit: '', color: 'var(--theme-green)' },
  ];

  const onSave = () => {
    save(weekKey, draft);
    setSaved(true);
    setTimeout(() => setSaved(false), 1800);
  };

  return (
    <div className="phone-shell safe-bottom">
      <PageHeader title="周度复盘" subtitle={`${formatDateCn(days[0])} - ${formatDateCn(days[6])}`} />

      {/* 周切换 */}
      <div className="flex items-center justify-between px-5 pt-3">
        <button
          onClick={() => setOffset((o) => o - 1)}
          aria-label="上一周"
          className="press flex size-9 items-center justify-center rounded-full bg-card text-muted-foreground shadow-[var(--ds-shadow-sm)] hover:text-foreground"
        >
          <ChevronLeft size={17} strokeWidth={2.6} />
        </button>
        <div className="text-center">
          <p className="text-[length:var(--font-size-label)] font-extrabold">
            {offset === 0 ? '本周' : offset === -1 ? '上周' : `${-offset} 周前`}
          </p>
          <p className="text-[10px] font-semibold text-muted-foreground">
            {days[0].slice(5).replace('-', '/')} — {days[6].slice(5).replace('-', '/')}
          </p>
        </div>
        <button
          onClick={() => setOffset((o) => Math.min(0, o + 1))}
          disabled={offset >= 0}
          aria-label="下一周"
          className="press flex size-9 items-center justify-center rounded-full bg-card text-muted-foreground shadow-[var(--ds-shadow-sm)] disabled:opacity-30 hover:text-foreground"
        >
          <ChevronRight size={17} strokeWidth={2.6} />
        </button>
      </div>

      {/* 自动统计 */}
      <div className="px-5 pt-4">
        <SectionTitle>本周数据</SectionTitle>
        <div className="grid grid-cols-4 gap-2">
          {stats.map((s, i) => (
            <motion.div
              key={s.label}
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: i * 0.05 }}
              className="flex flex-col items-center gap-1 rounded-[14px] bg-card py-3 shadow-[var(--ds-shadow-sm)] border border-[color-mix(in_oklab,var(--border)_50%,transparent)]"
            >
              <span style={{ color: s.color }}>{s.icon}</span>
              <p className="tnum text-[length:var(--font-size-label)] font-extrabold leading-none">
                {s.value}
                <span className="text-[9px] font-bold text-muted-foreground">{s.unit}</span>
              </p>
              <p className="text-[9px] font-bold text-muted-foreground">{s.label}</p>
            </motion.div>
          ))}
        </div>
      </div>

      {/* 每日打卡示意 */}
      <div className="px-5 pt-5">
        <SectionTitle>每日完成度</SectionTitle>
        <Card className="!p-3.5">
          <div className="flex items-end justify-between gap-1.5">
            {days.map((d, i) => {
              const done = habits.filter((h) => h.records.includes(d)).length;
              const pct = habits.length ? done / habits.length : 0;
              return (
                <div key={d} className="flex flex-1 flex-col items-center gap-1">
                  <div className="flex h-16 w-full items-end justify-center rounded-[6px] bg-secondary/70">
                    <motion.div
                      initial={{ height: 0 }}
                      animate={{ height: `${Math.max(pct * 100, pct > 0 ? 8 : 0)}%` }}
                      transition={{ duration: 0.5, delay: i * 0.04 }}
                      className="w-full rounded-[6px]"
                      style={{ background: 'var(--primary)', opacity: pct > 0 ? 1 : 0 }}
                    />
                  </div>
                  <span className="text-[9px] font-bold text-muted-foreground">
                    {['一', '二', '三', '四', '五', '六', '日'][i]}
                  </span>
                </div>
              );
            })}
          </div>
        </Card>
      </div>

      {/* 文字复盘 */}
      <div className="px-5 pt-5 pb-2">
        <SectionTitle>{offset === 0 ? '写下这周的复盘' : '回顾与回顾'}</SectionTitle>
        <div className="space-y-2.5">
          {AREAS.map((a) => (
            <div
              key={a.key}
              className="rounded-[var(--radius-lg)] bg-card p-3.5 shadow-[var(--ds-shadow-sm)] border border-[color-mix(in_oklab,var(--border)_50%,transparent)]"
              style={{ borderLeft: `3px solid ${a.color}` }}
            >
              <div className="mb-1.5 flex items-center gap-1.5">
                <span className="size-1.5 rounded-full" style={{ background: a.color }} />
                <span className="text-[length:var(--font-size-small)] font-extrabold">{a.label}</span>
              </div>
              <textarea
                value={draft[a.key]}
                onChange={(e) => setDraft((p) => ({ ...p, [a.key]: e.target.value }))}
                disabled={isFuture}
                placeholder={a.hint}
                rows={3}
                className="w-full resize-none rounded-[12px] bg-secondary/50 px-3 py-2 text-[length:var(--font-size-label)] font-medium leading-relaxed outline-none transition-colors placeholder:text-muted-foreground/70 focus:bg-secondary"
              />
            </div>
          ))}
        </div>

        <button
          onClick={onSave}
          disabled={isFuture}
          className="press mt-3 flex w-full items-center justify-center gap-1.5 rounded-[15px] py-3 text-[length:var(--font-size-body)] font-extrabold text-primary-foreground transition-opacity disabled:opacity-40"
          style={{
            background: saved ? 'var(--theme-green)' : 'var(--primary)',
            boxShadow: '0 8px 20px -8px color-mix(in oklab, var(--primary) 70%, transparent)',
          }}
        >
          {saved ? (
            <>
              <CheckCircle2 size={16} strokeWidth={2.8} /> 已保存
            </>
          ) : (
            <>
              <NotebookPen size={16} strokeWidth={2.6} /> 保存本周复盘
            </>
          )}
        </button>

        {record.updatedAt && (
          <p className="mt-2 text-center text-[10px] font-semibold text-muted-foreground">
            上次保存于 {new Date(record.updatedAt).toLocaleString('zh-CN', { month: 'numeric', day: 'numeric', hour: '2-digit', minute: '2-digit' })}
          </p>
        )}

        {/* 历史记录提示 */}
        {Object.keys(reviews).length > 0 && (
          <div className="mt-4 flex items-center justify-center gap-1 rounded-[12px] bg-secondary/60 py-2">
            <Lightbulb size={12} className="text-muted-foreground" strokeWidth={2.6} />
            <span className="text-[10px] font-semibold text-muted-foreground">
              已累计 {Object.keys(reviews).length} 周复盘记录
            </span>
          </div>
        )}
      </div>

      <TabBar />
    </div>
  );
}
