import { useMemo, useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Check, ListTodo, Plus, Trash2, Calendar } from 'lucide-react';
import { PageHeader, Empty, Segmented, Tag } from '@/components/workspace/UI';
import { Sheet, TextInput, Field, ChipGroup, PrimaryButton, TextArea } from '@/components/workspace/Sheet';
import { TabBar } from '@/components/workspace/TabBar';
import { useTodos } from '@/hooks/useWorkspace';
import { todayKey, relativeDay, formatDateCn } from '@/lib/date';
import type { Priority } from '@/types/workspace';

const PRIORITY: { value: Priority; label: string; color: string }[] = [
  { value: 'high', label: '高', color: 'oklch(0.62 0.2 28)' },
  { value: 'mid', label: '中', color: 'oklch(0.72 0.15 70)' },
  { value: 'low', label: '低', color: 'oklch(0.62 0.1 200)' },
];

type View = 'today' | 'all' | 'done';

export default function Todos() {
  const { todos, add, toggle, remove } = useTodos();
  const [view, setView] = useState<View>('all');
  const [open, setOpen] = useState(false);
  const [title, setTitle] = useState('');
  const [priority, setPriority] = useState<Priority>('mid');
  const [due, setDue] = useState(todayKey());
  const [note, setNote] = useState('');
  const [showForm, setShowForm] = useState(false);

  const today = todayKey();

  const list = useMemo(() => {
    if (view === 'today') return todos.filter((t) => !t.done && t.due === today);
    if (view === 'done') return todos.filter((t) => t.done);
    return todos.filter((t) => !t.done);
  }, [todos, view, today]);

  const submit = () => {
    if (!title.trim()) return;
    add(title, priority, due || undefined, note || undefined);
    setTitle('');
    setNote('');
    setShowForm(false);
    setPriority('mid');
    setDue(todayKey());
    setOpen(false);
  };

  const counts = {
    today: todos.filter((t) => !t.done && t.due === today).length,
    all: todos.filter((t) => !t.done).length,
    done: todos.filter((t) => t.done).length,
  };

  return (
    <div className="phone-shell safe-bottom">
      <PageHeader
        title="待办清单"
        subtitle={`未完成 ${counts.all} 项 · 已完成 ${counts.done} 项`}
        back={false}
      />

      {/* 快速添加 */}
      <div className="px-5 pt-3">
        <form
          onSubmit={(e) => {
            e.preventDefault();
            if (!title.trim()) return;
            add(title, 'mid', today);
            setTitle('');
          }}
          className="flex items-center gap-2"
        >
          <div className="relative flex-1">
            <TextInput
              value={title}
              onChange={(e) => setTitle(e.target.value)}
              placeholder="添加一件事，回车即可…"
              className="!bg-card !py-2.5 !pl-9 shadow-[var(--ds-shadow-sm)]"
            />
            <Plus
              size={16}
              className="pointer-events-none absolute left-3 top-1/2 -translate-y-1/2 text-muted-foreground"
              strokeWidth={2.6}
            />
          </div>
          <button
            type="button"
            onClick={() => setOpen(true)}
            aria-label="详细添加"
            className="press flex size-[42px] shrink-0 items-center justify-center rounded-[14px] text-primary-foreground"
            style={{ background: 'var(--primary)' }}
          >
            <Calendar size={17} strokeWidth={2.5} />
          </button>
        </form>
      </div>

      {/* 视图切换 */}
      <div className="px-5 pt-3">
        <Segmented
          value={view}
          onChange={setView}
          options={[
            { value: 'today', label: `今日 ${counts.today || ''}`.trim() },
            { value: 'all', label: `未完成 ${counts.all || ''}`.trim() },
            { value: 'done', label: `已完成 ${counts.done || ''}`.trim() },
          ]}
        />
      </div>

      {/* 列表 */}
      <div className="px-5 pt-4">
        {list.length === 0 ? (
          <Empty
            icon={<ListTodo size={26} strokeWidth={1.8} />}
            text={view === 'done' ? '还没有完成的待办' : '暂无待办事项'}
            hint={view === 'today' ? '今天还没有安排，试着添加一件事' : '在上方输入框写下第一件事吧'}
          />
        ) : (
          <div className="space-y-2">
            <AnimatePresence initial={false}>
              {list.map((t) => {
                const p = PRIORITY.find((x) => x.value === t.priority)!;
                const overdue = !t.done && t.due && t.due < today;
                return (
                  <motion.div
                    key={t.id}
                    layout
                    initial={{ opacity: 0, y: 8 }}
                    animate={{ opacity: 1, y: 0 }}
                    exit={{ opacity: 0, x: -30, height: 0, marginBottom: 0 }}
                    transition={{ duration: 0.22 }}
                    className="group flex items-start gap-3 rounded-[var(--radius-lg)] border border-[color-mix(in_oklab,var(--border)_50%,transparent)] bg-card p-3.5 shadow-[var(--ds-shadow-sm)]"
                  >
                    <button
                      onClick={() => toggle(t.id)}
                      aria-label={t.done ? '标记未完成' : '标记完成'}
                      className="mt-0.5 flex size-[22px] shrink-0 items-center justify-center rounded-full border-2 transition-all"
                      style={{
                        borderColor: t.done ? 'var(--theme-green)' : 'var(--border)',
                        background: t.done ? 'var(--theme-green)' : 'transparent',
                      }}
                    >
                      {t.done && <Check size={13} color="#fff" strokeWidth={3.6} />}
                    </button>

                    <div className="min-w-0 flex-1">
                      <p
                        className={`text-[length:var(--font-size-label)] font-semibold leading-snug transition-all ${
                          t.done ? 'text-muted-foreground line-through opacity-60' : ''
                        }`}
                      >
                        {t.title}
                      </p>
                      {t.note && (
                        <p className="mt-1 line-clamp-2 text-[10px] leading-relaxed text-muted-foreground">
                          {t.note}
                        </p>
                      )}
                      <div className="mt-1.5 flex flex-wrap items-center gap-1.5">
                        <Tag color={p.color}>{p.label}优先</Tag>
                        {t.due && (
                          <Tag color={overdue ? 'oklch(0.62 0.2 28)' : undefined}>
                            {overdue ? '⚠ ' : ''}
                            {relativeDay(t.due)}
                          </Tag>
                        )}
                        {t.done && t.doneAt && (
                          <Tag color="var(--theme-green)">
                            ✓ {formatDateCn(t.doneAt.slice(0, 10))}完成
                          </Tag>
                        )}
                      </div>
                    </div>

                    <button
                      onClick={() => remove(t.id)}
                      aria-label="删除"
                      className="mt-0.5 flex size-7 shrink-0 items-center justify-center rounded-full text-muted-foreground/50 opacity-0 transition-all hover:bg-destructive/10 hover:text-destructive group-hover:opacity-100"
                    >
                      <Trash2 size={14} strokeWidth={2.4} />
                    </button>
                  </motion.div>
                );
              })}
            </AnimatePresence>
          </div>
        )}
      </div>

      {/* 详细添加 */}
      <Sheet open={open} onClose={() => setOpen(false)} title="新增待办">
        <Field label="要做什么">
          <TextInput
            autoFocus
            value={title}
            onChange={(e) => setTitle(e.target.value)}
            placeholder="例如：整理季度报表"
          />
        </Field>
        <Field label="优先级">
          <ChipGroup value={priority} onChange={setPriority} options={PRIORITY} />
        </Field>
        <Field label="截止日期">
          <TextInput type="date" value={due} onChange={(e) => setDue(e.target.value)} />
        </Field>
        {showForm ? (
          <Field label="备注">
            <TextArea
              rows={2}
              value={note}
              onChange={(e) => setNote(e.target.value)}
              placeholder="补充说明（可选）"
            />
          </Field>
        ) : (
          <button
            onClick={() => setShowForm(true)}
            className="mb-3 text-[length:var(--font-size-small)] font-bold text-primary"
          >
            + 添加备注
          </button>
        )}
        <PrimaryButton onClick={submit} disabled={!title.trim()}>
          添加待办
        </PrimaryButton>
      </Sheet>

      <TabBar />
    </div>
  );
}
