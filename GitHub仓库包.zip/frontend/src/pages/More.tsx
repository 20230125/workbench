import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { motion } from 'framer-motion';
import {
  BellRing,
  ListTodo,
  Flame,
  Wallet,
  Boxes,
  Lightbulb,
  NotebookPen,
  ChevronRight,
  NotebookPen as Note,
  Database,
  Download,
  Upload,
  Trash2,
  CalendarDays,
  Sparkles,
  CheckCircle2,
  Palette,
} from 'lucide-react';
import { PageHeader, SectionTitle, Tag } from '@/components/workspace/UI';
import { TabBar } from '@/components/workspace/TabBar';
import { InstallGuide, DisplayModeBadge } from '@/components/workspace/InstallGuide';
import { useTodos, useReminders, useHabits, useLedger, useStorage, useIdeas, useReviews } from '@/hooks/useWorkspace';
import { store, useLocalStore } from '@/lib/store';
import { todayKey, formatDateCn } from '@/lib/date';
import { globalStreak } from '@/lib/stats';
import type { Meta } from '@/types/workspace';

const MODULES = [
  { path: '/reminders', label: '事项提醒', desc: '按分类管理日程提醒', icon: BellRing, color: 'var(--primary)' },
  { path: '/todos', label: '待办清单', desc: '优先级 / 截止日期', icon: ListTodo, color: 'var(--theme-blue)' },
  { path: '/habits', label: '习惯打卡', desc: '每日坚持 + 连续记录', icon: Flame, color: 'var(--theme-gold)' },
  { path: '/ledger', label: '记账本', desc: '收支记录与月度汇总', icon: Wallet, color: 'var(--theme-green)' },
  { path: '/storage', label: '储物清单', desc: '东西放在哪里', icon: Boxes, color: 'oklch(0.66 0.11 200)' },
  { path: '/ideas', label: '灵感库', desc: '随手记下的念头', icon: Lightbulb, color: 'oklch(0.72 0.14 85)' },
  { path: '/review', label: '周度复盘', desc: '每周回顾与目标', icon: NotebookPen, color: 'oklch(0.64 0.13 300)' },
  { path: '/appearance', label: '外观设置', desc: '配色 / 深色 / 圆角 / 字号', icon: Palette, color: 'var(--primary)' },
];

export default function More() {
  const nav = useNavigate();
  const { todos } = useTodos();
  const { reminders } = useReminders();
  const { habits } = useHabits();
  const { entries } = useLedger();
  const { items } = useStorage();
  const { ideas } = useIdeas();
  const { reviews } = useReviews();
  const [meta, setMeta] = useLocalStore<Meta>('meta', { lastOpen: todayKey(), nickname: '我' });
  const [toast, setToast] = useState('');

  const showToast = (msg: string) => {
    setToast(msg);
    setTimeout(() => setToast(''), 2000);
  };

  const exportData = () => {
    const data: Record<string, unknown> = {};
    ['todos', 'reminders', 'habits', 'ledger', 'storage', 'ideas', 'reviews', 'meta'].forEach((k) => {
      const raw = localStorage.getItem(store.PREFIX + k);
      if (raw) data[k] = JSON.parse(raw);
    });
    const blob = new Blob([JSON.stringify({ exportedAt: new Date().toISOString(), data }, null, 2)], {
      type: 'application/json',
    });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `工作台备份_${todayKey()}.json`;
    a.click();
    URL.revokeObjectURL(url);
    showToast('已导出备份文件');
  };

  const importData = () => {
    const input = document.createElement('input');
    input.type = 'file';
    input.accept = 'application/json';
    input.onchange = () => {
      const file = input.files?.[0];
      if (!file) return;
      const reader = new FileReader();
      reader.onload = () => {
        try {
          const parsed = JSON.parse(String(reader.result));
          const payload = parsed.data || parsed;
          Object.entries(payload).forEach(([k, v]) => {
            localStorage.setItem(store.PREFIX + k, JSON.stringify(v));
          });
          showToast('导入成功，正在刷新…');
          setTimeout(() => window.location.reload(), 800);
        } catch {
          showToast('文件格式不正确');
        }
      };
      reader.readAsText(file);
    };
    input.click();
  };

  const clearAll = () => {
    if (!confirm('确定清空全部数据吗？此操作不可恢复，建议先导出备份。')) return;
    ['todos', 'reminders', 'habits', 'ledger', 'storage', 'ideas', 'reviews', 'meta'].forEach((k) => {
      localStorage.removeItem(store.PREFIX + k);
    });
    showToast('数据已清空，正在刷新…');
    setTimeout(() => window.location.reload(), 700);
  };

  const totalRecords =
    todos.length +
    reminders.length +
    habits.reduce((s, h) => s + h.records.length, 0) +
    entries.length +
    items.length +
    ideas.length;

  const streak = globalStreak(habits);

  return (
    <div className="phone-shell safe-bottom">
      <PageHeader title="更多" back={false} />

      {/* 个人概览 */}
      <section className="px-5 pt-3">
        <div
          className="relative overflow-hidden rounded-[var(--radius-lg)] p-4"
          style={{
            background:
              'linear-gradient(135deg, color-mix(in oklab, var(--primary) 14%, var(--card)), color-mix(in oklab, oklch(0.82 0.13 84) 20%, var(--card)))',
            border: '1px solid color-mix(in oklab, var(--primary) 16%, transparent)',
          }}
        >
          <div className="flex items-center gap-3">
            <div
              className="flex size-12 shrink-0 items-center justify-center rounded-[16px] text-[22px]"
              style={{ background: 'var(--card)' }}
            >
              🌤
            </div>
            <div className="min-w-0 flex-1">
              <div className="flex items-center gap-1.5">
                <input
                  value={meta.nickname}
                  onChange={(e) => setMeta({ ...meta, nickname: e.target.value })}
                  className="w-[100px] rounded-md bg-transparent px-0 text-[length:var(--font-size-body)] font-extrabold outline-none focus:bg-card/60"
                  aria-label="昵称"
                />
                <Note size={11} className="text-muted-foreground" />
              </div>
              <p className="mt-0.5 text-[10px] font-semibold text-muted-foreground">
                连续打卡 {streak} 天 · 累计 {totalRecords} 条记录
              </p>
            </div>
          </div>
          <div className="mt-3 grid grid-cols-3 gap-2">
            {[
              { label: '待办', n: todos.filter((t) => !t.done).length },
              { label: '提醒', n: reminders.filter((r) => !r.done).length },
              { label: '复盘', n: Object.keys(reviews).length },
            ].map((s) => (
              <div key={s.label} className="rounded-[12px] bg-card/70 py-2 text-center">
                <p className="tnum text-[length:var(--font-size-label)] font-extrabold">{s.n}</p>
                <p className="text-[9px] font-bold text-muted-foreground">{s.label}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* 全部模块 */}
      <section className="px-5 pt-5">
        <SectionTitle>全部功能</SectionTitle>
        <div className="overflow-hidden rounded-[var(--radius-lg)] bg-card shadow-[var(--ds-shadow-sm)] border border-[color-mix(in_oklab,var(--border)_50%,transparent)]">
          {MODULES.map((m, i) => {
            const Icon = m.icon;
            return (
              <button
                key={m.path}
                onClick={() => nav(m.path)}
                className="group flex w-full items-center gap-3 px-4 py-3 text-left transition-colors hover:bg-secondary/50"
                style={{
                  borderTop: i === 0 ? 'none' : '1px solid color-mix(in oklab, var(--border) 45%, transparent)',
                }}
              >
                <span
                  className="flex size-9 shrink-0 items-center justify-center rounded-[11px]"
                  style={{
                    background: `color-mix(in oklab, ${m.color} 14%, transparent)`,
                    color: m.color,
                  }}
                >
                  <Icon size={16} strokeWidth={2.5} />
                </span>
                <div className="min-w-0 flex-1">
                  <p className="text-[length:var(--font-size-label)] font-bold">{m.label}</p>
                  <p className="text-[10px] font-medium text-muted-foreground">{m.desc}</p>
                </div>
                <ChevronRight
                  size={15}
                  className="shrink-0 text-muted-foreground/50 transition-transform group-hover:translate-x-0.5"
                  strokeWidth={2.6}
                />
              </button>
            );
          })}
        </div>
      </section>

      {/* 全屏 App 安装引导 */}
      <section className="px-5 pt-5">
        <SectionTitle>全屏 App 模式</SectionTitle>
        <InstallGuide />
        <div className="mt-2">
          <DisplayModeBadge />
        </div>
      </section>

      {/* 数据 */}
      <section className="px-5 pt-5 pb-2">
        <SectionTitle>数据管理</SectionTitle>
        <div className="space-y-2">
          <div className="flex items-center gap-3 rounded-[var(--radius-lg)] bg-card px-4 py-3 shadow-[var(--ds-shadow-sm)] border border-[color-mix(in_oklab,var(--border)_50%,transparent)]">
            <span className="flex size-9 items-center justify-center rounded-[11px] bg-secondary text-muted-foreground">
              <Database size={15} strokeWidth={2.5} />
            </span>
            <div className="flex-1">
              <p className="text-[length:var(--font-size-label)] font-bold">本地存储</p>
              <p className="text-[10px] font-medium text-muted-foreground">
                所有数据保存在本机浏览器，不上传云端
              </p>
            </div>
            <Tag color="var(--theme-green)">
              <CheckCircle2 size={9} className="mr-0.5" strokeWidth={3} /> 已启用
            </Tag>
          </div>

          <div className="grid grid-cols-2 gap-2">
            <button
              onClick={exportData}
              className="press flex items-center justify-center gap-1.5 rounded-[14px] bg-card py-3 text-[length:var(--font-size-small)] font-bold shadow-[var(--ds-shadow-sm)] border border-[color-mix(in_oklab,var(--border)_50%,transparent)] hover:text-primary"
            >
              <Download size={14} strokeWidth={2.6} /> 导出备份
            </button>
            <button
              onClick={importData}
              className="press flex items-center justify-center gap-1.5 rounded-[14px] bg-card py-3 text-[length:var(--font-size-small)] font-bold shadow-[var(--ds-shadow-sm)] border border-[color-mix(in_oklab,var(--border)_50%,transparent)] hover:text-primary"
            >
              <Upload size={14} strokeWidth={2.6} /> 导入备份
            </button>
          </div>

          <button
            onClick={clearAll}
            className="press flex w-full items-center justify-center gap-1.5 rounded-[14px] bg-card py-3 text-[length:var(--font-size-small)] font-bold text-destructive shadow-[var(--ds-shadow-sm)] border border-[color-mix(in_oklab,var(--border)_50%,transparent)] hover:bg-destructive/5"
          >
            <Trash2 size={14} strokeWidth={2.6} /> 清空全部数据
          </button>
        </div>

        {/* 说明 */}
        <div className="mt-4 space-y-2 rounded-[var(--radius-lg)] bg-secondary/50 p-3.5">
          <p className="flex items-center gap-1.5 text-[10px] font-extrabold text-foreground/75">
            <CalendarDays size={11} strokeWidth={2.8} /> 每日重置 & 累积记录说明
          </p>
          <ul className="space-y-1 text-[10px] leading-relaxed text-muted-foreground">
            <li>· 打卡状态每天按日期重置，历史记录永久保留</li>
            <li>· 提醒的过期状态按今天实时计算</li>
            <li>· 待办、记账、储物、灵感持续累积，不会清空</li>
            <li>· 周复盘按自然周（周一起）独立保存</li>
            <li>· 首页激励语每天自动更新，也可手动换一句</li>
          </ul>
          <p className="flex items-center gap-1 pt-0.5 text-[9px] font-semibold text-muted-foreground/80">
            <Sparkles size={9} strokeWidth={3} /> 上次打开：{formatDateCn(meta.lastOpen)}
          </p>
        </div>
      </section>

      {/* Toast */}
      {toast && (
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          exit={{ opacity: 0 }}
          className="fixed bottom-[calc(160px+env(safe-area-inset-bottom,0px))] left-1/2 z-50 -translate-x-1/2 rounded-full bg-foreground/90 px-4 py-2 text-[length:var(--font-size-small)] font-bold text-background shadow-lg"
        >
          {toast}
        </motion.div>
      )}

      <TabBar />
    </div>
  );
}
