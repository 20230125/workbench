import { useMemo, useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { BellRing, Check, Trash2, Clock, Plus } from 'lucide-react';
import { PageHeader, Empty, Tag } from '@/components/workspace/UI';
import { Sheet, TextInput, TextArea, Field, ChipGroup, PrimaryButton } from '@/components/workspace/Sheet';
import { TabBar } from '@/components/workspace/TabBar';
import { useReminders } from '@/hooks/useWorkspace';
import { todayKey, relativeDay, formatDateCn, diffDays } from '@/lib/date';
import type { ReminderCategory } from '@/types/workspace';

export const CATEGORIES: { value: ReminderCategory; label: string; color: string; emoji: string }[] = [
  { value: 'work', label: '工作', color: 'oklch(0.6 0.15 250)', emoji: '💼' },
  { value: 'life', label: '生活', color: 'oklch(0.68 0.15 40)', emoji: '🏠' },
  { value: 'health', label: '健康', color: 'oklch(0.64 0.14 150)', emoji: '💚' },
  { value: 'study', label: '学习', color: 'oklch(0.64 0.14 300)', emoji: '📚' },
  { value: 'other', label: '其他', color: 'oklch(0.6 0.02 60)', emoji: '📌' },
];

type Filter = 'all' | 'today' | 'overdue' | 'done';

export default function Reminders() {
  const { reminders, add, toggle, remove } = useReminders();
  const [filter, setFilter] = useState<Filter>('all');
  const [open, setOpen] = useState(false);
  const [title, setTitle] = useState('');
  const [category, setCategory] = useState<ReminderCategory>('work');
  const [date, setDate] = useState(todayKey());
  const [time, setTime] = useState('09:00');
  const [note, setNote] = useState('');

  const today = todayKey();

  const filtered = useMemo(() => {
    let arr = reminders;
    if (filter === 'today') arr = reminders.filter((r) => !r.done && r.date === today);
    if (filter === 'overdue') arr = reminders.filter((r) => !r.done && r.date < today);
    if (filter === 'done') arr = reminders.filter((r) => r.done);
    return [...arr].sort((a, b) => (a.date + (a.time || '')).localeCompare(b.date + (b.time || '')));
  }, [reminders, filter, today]);

  const grouped = useMemo(() => {
    const map = new Map<string, typeof filtered>();
    filtered.forEach((r) => {
      const k = r.date;
      if (!map.has(k)) map.set(k, []);
      map.get(k)!.push(r);
    });
    return [...map.entries()];
  }, [filtered]);

  const counts = {
    all: reminders.filter((r) => !r.done).length,
    today: reminders.filter((r) => !r.done && r.date === today).length,
    overdue: reminders.filter((r) => !r.done && r.date < today).length,
    done: reminders.filter((r) => r.done).length,
  };

  const submit = () => {
    if (!title.trim()) return;
    add({ title: title.trim(), category, date, time, note: note || undefined });
    setTitle('');
    setNote('');
    setTime('09:00');
    setDate(todayKey());
    setOpen(false);
  };

  return (
    <div className="phone-shell safe-bottom">
      <PageHeader
        title="事项提醒"
        subtitle={`今天 ${counts.today} 件 · 逾期 ${counts.overdue} 件`}
      />

      {/* 分类概览 */}
      <div className="px-5 pt-3">
        <div className="grid grid-cols-5 gap-1.5">
          {CATEGORIES.map((c) => {
            const n = reminders.filter((r) => !r.done && r.category === c.value).length;
            return (
              <button
                key={c.value}
                onClick={() => setFilter('all')}
                className="press flex flex-col items-center gap-1 rounded-[14px] bg-card py-2.5 shadow-[var(--ds-shadow-sm)] border border-[color-mix(in_oklab,var(--border)_50%,transparent)]"
              >
                <span
                  className="flex size-7 items-center justify-center rounded-[9px] text-[13px]"
                  style={{ background: `color-mix(in oklab, ${c.color} 15%, transparent)` }}
                >
                  {c.emoji}
                </span>
                <span className="text-[9px] font-bold text-muted-foreground">{c.label}</span>
                <span className="text-[11px] font-extrabold" style={{ color: c.color }}>
                  {n}
                </span>
              </button>
            );
          })}
        </div>
      </div>

      {/* 筛选 */}
      <div className="flex gap-1.5 overflow-x-auto px-5 pt-3">
        {(
          [
            { v: 'all', l: '全部', n: counts.all },
            { v: 'today', l: '今天', n: counts.today },
            { v: 'overdue', l: '已过期', n: counts.overdue },
            { v: 'done', l: '已完成', n: counts.done },
          ] as { v: Filter; l: string; n: number }[]
        ).map((f) => {
          const active = filter === f.v;
          return (
            <button
              key={f.v}
              onClick={() => setFilter(f.v)}
              className="shrink-0 rounded-full px-3 py-1.5 text-[length:var(--font-size-small)] font-bold transition-colors"
              style={
                active
                  ? { background: 'var(--primary)', color: 'var(--primary-foreground)' }
                  : { background: 'var(--secondary)', color: 'var(--muted-foreground)' }
              }
            >
              {f.l}
              {f.n > 0 && <span className="ml-1 opacity-70">{f.n}</span>}
            </button>
          );
        })}
      </div>

      {/* 列表 */}
      <div className="px-5 pt-4">
        {grouped.length === 0 ? (
          <Empty
            icon={<BellRing size={26} strokeWidth={1.8} />}
            text="暂无提醒事项"
            hint="点右下角 + 添加一条，别让重要的事被忘掉"
          />
        ) : (
          <div className="space-y-4">
            {grouped.map(([dateKey, list]) => {
              const overdue = dateKey < today;
              const isToday = dateKey === today;
              return (
                <div key={dateKey}>
                  <div className="mb-1.5 flex items-center gap-2 px-1">
                    <span
                      className="text-[length:var(--font-size-small)] font-extrabold"
                      style={{
                        color: overdue
                          ? 'var(--theme-red)'
                          : isToday
                            ? 'var(--primary)'
                            : 'var(--foreground)',
                      }}
                    >
                      {relativeDay(dateKey)}
                    </span>
                    <span className="text-[10px] font-semibold text-muted-foreground">
                      {formatDateCn(dateKey)}
                      {overdue && ` · ${diffDays(today, dateKey)} 天前`}
                    </span>
                    <div className="h-px flex-1 bg-border/70" />
                    <span className="text-[10px] font-bold text-muted-foreground">
                      {list.length}
                    </span>
                  </div>
                  <div className="space-y-2">
                    <AnimatePresence initial={false}>
                      {list.map((r) => {
                        const c = CATEGORIES.find((x) => x.value === r.category)!;
                        return (
                          <motion.div
                            key={r.id}
                            layout
                            initial={{ opacity: 0, y: 8 }}
                            animate={{ opacity: 1, y: 0 }}
                            exit={{ opacity: 0, height: 0, marginBottom: 0 }}
                            transition={{ duration: 0.2 }}
                            className="group flex items-start gap-3 rounded-[var(--radius-lg)] bg-card p-3.5 shadow-[var(--ds-shadow-sm)] border border-[color-mix(in_oklab,var(--border)_50%,transparent)]"
                          >
                            <button
                              onClick={() => toggle(r.id)}
                              aria-label="完成"
                              className="mt-0.5 flex size-[22px] shrink-0 items-center justify-center rounded-full border-2 transition-all"
                              style={{
                                borderColor: r.done ? 'var(--theme-green)' : 'var(--border)',
                                background: r.done ? 'var(--theme-green)' : 'transparent',
                              }}
                            >
                              {r.done && <Check size={13} color="#fff" strokeWidth={3.6} />}
                            </button>
                            <div className="min-w-0 flex-1">
                              <p
                                className={`text-[length:var(--font-size-label)] font-semibold leading-snug ${
                                  r.done ? 'text-muted-foreground line-through opacity-60' : ''
                                }`}
                              >
                                {r.title}
                              </p>
                              <div className="mt-1.5 flex flex-wrap items-center gap-1.5">
                                <Tag color={c.color}>
                                  {c.emoji} {c.label}
                                </Tag>
                                {r.time && (
                                  <Tag>
                                    <Clock size={9} className="mr-0.5" strokeWidth={3} />
                                    {r.time}
                                  </Tag>
                                )}
                                {!r.done && r.date < today && (
                                  <Tag color="oklch(0.62 0.2 28)">已过期</Tag>
                                )}
                              </div>
                              {r.note && (
                                <p className="mt-1.5 text-[10px] leading-relaxed text-muted-foreground">
                                  {r.note}
                                </p>
                              )}
                            </div>
                            <button
                              onClick={() => remove(r.id)}
                              aria-label="删除"
                              className="mt-0.5 flex size-7 shrink-0 items-center justify-center rounded-full text-muted-foreground/50 opacity-0 transition-all hover:bg-destructive/10 hover:text-destructive group-hover:opacity-100"
                            >
                              <Trash2 size={14} strokeWidth={2.4} />
                            </button>
                          </motion.div>
                        );
                      })}
                    </AnimatePresence>
                  </div>
                </div>
              );
            })}
          </div>
        )}
      </div>

      {/* 新增按钮 */}
      <motion.button
        initial={{ scale: 0 }}
        animate={{ scale: 1 }}
        transition={{ type: 'spring', damping: 14, stiffness: 260 }}
        whileTap={{ scale: 0.9 }}
        onClick={() => setOpen(true)}
        aria-label="新增提醒"
        className="fixed bottom-[calc(96px+env(safe-area-inset-bottom,0px))] right-[max(20px,calc(50%-220px))] z-30 flex size-14 items-center justify-center rounded-full text-primary-foreground shadow-[0_10px_24px_-6px_color-mix(in_oklab,var(--primary)_65%,transparent)]"
        style={{ background: 'var(--primary)' }}
      >
        <Plus size={26} strokeWidth={2.6} />
      </motion.button>

      <Sheet open={open} onClose={() => setOpen(false)} title="新增提醒">
        <Field label="提醒什么">
          <TextInput
            autoFocus
            value={title}
            onChange={(e) => setTitle(e.target.value)}
            placeholder="例如：交房租 / 取快递 / 复诊"
          />
        </Field>
        <Field label="分类">
          <ChipGroup
            value={category}
            onChange={setCategory}
            options={CATEGORIES.map((c) => ({
              value: c.value,
              label: `${c.emoji} ${c.label}`,
              color: c.color,
            }))}
          />
        </Field>
        <div className="grid grid-cols-2 gap-2">
          <Field label="日期">
            <TextInput type="date" value={date} onChange={(e) => setDate(e.target.value)} />
          </Field>
          <Field label="时间">
            <TextInput type="time" value={time} onChange={(e) => setTime(e.target.value)} />
          </Field>
        </div>
        <Field label="备注">
          <TextArea
            rows={2}
            value={note}
            onChange={(e) => setNote(e.target.value)}
            placeholder="补充说明（可选）"
          />
        </Field>
        <PrimaryButton onClick={submit} disabled={!title.trim()}>
          添加提醒
        </PrimaryButton>
      </Sheet>

      <TabBar />
    </div>
  );
}
