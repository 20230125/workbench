import { Check, RotateCcw, Sun, Moon, Smartphone, Palette } from 'lucide-react';
import { PageHeader, SectionTitle } from '@/components/workspace/UI';
import { TabBar } from '@/components/workspace/TabBar';
import { useTheme } from '@/hooks/useTheme';
import { PRESETS, swatch, type ThemeMode } from '@/lib/theme';

const MODES: { key: ThemeMode; label: string; icon: typeof Sun }[] = [
  { key: 'light', label: '浅色', icon: Sun },
  { key: 'dark', label: '深色', icon: Moon },
  { key: 'auto', label: '跟随系统', icon: Smartphone },
];

export default function Appearance() {
  const { theme, setTheme, reset } = useTheme();

  const patch = (p: Partial<typeof theme>) => setTheme({ ...theme, ...p });

  return (
    <div className="phone-shell safe-bottom">
      <PageHeader title="外观设置" subtitle="调色、明暗、圆角与字号" />

      {/* ── 实时预览 ── */}
      <section className="px-5 pt-4">
        <div
          className="relative overflow-hidden rounded-[var(--radius-lg)] p-4"
          style={{
            background:
              'linear-gradient(135deg, color-mix(in oklab, var(--primary) 88%, transparent), color-mix(in oklab, var(--primary) 55%, oklch(0.82 0.13 84)))',
          }}
        >
          <p
            className="text-[length:var(--font-size-small)] font-bold"
            style={{ color: 'var(--primary-foreground)' }}
          >
            实时预览 · {PRESETS.find((p) => p.hue === theme.hue)?.name ?? '自定义配色'}
          </p>
          <p
            className="tnum mt-1 text-[26px] font-extrabold leading-none"
            style={{ color: 'var(--primary-foreground)' }}
          >
            20:50
          </p>
          <div className="mt-3 flex gap-2">
            <span
              className="rounded-full px-3 py-1.5 text-[11px] font-bold"
              style={{
                background: 'color-mix(in oklab, var(--card) 92%, transparent)',
                color: 'var(--primary)',
              }}
            >
              打卡
            </span>
            <span
              className="rounded-full px-3 py-1.5 text-[11px] font-bold"
              style={{
                background: 'color-mix(in oklab, var(--primary-foreground) 92%, transparent)',
                color: 'var(--primary)',
              }}
            >
              已完成
            </span>
          </div>
        </div>
      </section>

      {/* ── 预设配色 ── */}
      <section className="px-5 pt-5">
        <SectionTitle hint="点一下换整套配色">配色方案</SectionTitle>
        <div
          style={{
            display: 'grid',
            gridTemplateColumns: 'repeat(4, minmax(0, 1fr))',
            gap: '10px',
          }}
        >
          {PRESETS.map((p) => {
            const active = theme.hue === p.hue && Math.abs(theme.chroma - p.chroma) < 0.02;
            return (
              <button
                key={p.key}
                onClick={() => patch({ hue: p.hue, chroma: p.chroma })}
                className="press relative flex flex-col items-center gap-1.5 rounded-[14px] bg-card py-2.5 shadow-[var(--ds-shadow-sm)]"
                style={{
                  border: active
                    ? '2px solid var(--primary)'
                    : '1px solid color-mix(in oklab, var(--border) 55%, transparent)',
                }}
                aria-pressed={active}
              >
                <span
                  className="relative flex size-8 items-center justify-center rounded-full"
                  style={{
                    background: `linear-gradient(135deg, ${swatch(p.hue, p.chroma)}, ${swatch(p.hue + 18, p.chroma)})`,
                  }}
                >
                  {active && <Check size={15} strokeWidth={3.4} className="text-white" />}
                </span>
                <span className="text-[10px] font-bold leading-tight">{p.name}</span>
              </button>
            );
          })}
        </div>
      </section>

      {/* ── 色相滑块 ── */}
      <section className="px-5 pt-5">
        <SectionTitle hint={theme.hue === 31 ? '默认' : `${theme.hue}°`}>主色调</SectionTitle>
        <div className="rounded-[var(--radius-lg)] bg-card p-4 shadow-[var(--ds-shadow-sm)] border border-[color-mix(in_oklab,var(--border)_50%,transparent)]">
          <input
            type="range"
            min={0}
            max={360}
            step={1}
            value={theme.hue}
            onChange={(e) => patch({ hue: Number(e.target.value) })}
            className="theme-slider w-full"
            aria-label="色相"
            style={{
              background:
                'linear-gradient(90deg, oklch(0.7 0.16 0), oklch(0.7 0.16 60), oklch(0.7 0.16 120), oklch(0.7 0.16 180), oklch(0.7 0.16 240), oklch(0.7 0.16 300), oklch(0.7 0.16 360))',
            }}
          />
          <div className="mt-3 flex items-center justify-between">
            <span className="text-[11px] font-semibold text-muted-foreground">饱和度</span>
            <span className="tnum text-[11px] font-bold text-primary">
              {Math.round(theme.chroma * 100)}%
            </span>
          </div>
          <input
            type="range"
            min={55}
            max={150}
            step={1}
            value={Math.round(theme.chroma * 100)}
            onChange={(e) => patch({ chroma: Number(e.target.value) / 100 })}
            className="theme-slider mt-2 w-full"
            aria-label="饱和度"
            style={{
              background: `linear-gradient(90deg, ${swatch(theme.hue, 0.55)}, ${swatch(theme.hue, 1)})`,
            }}
          />
          <p className="mt-3 text-[10px] leading-relaxed text-muted-foreground">
            拖动滑块，全站主色实时变化。数值越低越素雅，越高越鲜明。
          </p>
        </div>
      </section>

      {/* ── 明暗模式 ── */}
      <section className="px-5 pt-5">
        <SectionTitle>显示模式</SectionTitle>
        <div
          style={{ display: 'grid', gridTemplateColumns: 'repeat(3, minmax(0,1fr))', gap: '8px' }}
        >
          {MODES.map((m) => {
            const Icon = m.icon;
            const active = theme.mode === m.key;
            return (
              <button
                key={m.key}
                onClick={() => patch({ mode: m.key })}
                className="press flex flex-col items-center gap-1.5 rounded-[14px] py-3 shadow-[var(--ds-shadow-sm)]"
                style={{
                  background: active ? 'var(--primary)' : 'var(--card)',
                  color: active ? 'var(--primary-foreground)' : 'var(--foreground)',
                  border: active
                    ? '1px solid var(--primary)'
                    : '1px solid color-mix(in oklab, var(--border) 55%, transparent)',
                }}
                aria-pressed={active}
              >
                <Icon size={17} strokeWidth={2.5} />
                <span className="text-[10px] font-bold">{m.label}</span>
              </button>
            );
          })}
        </div>
      </section>

      {/* ── 圆角 & 字号 ── */}
      <section className="px-5 pt-5">
        <SectionTitle>细节</SectionTitle>
        <div className="space-y-2">
          <div className="rounded-[var(--radius-lg)] bg-card px-4 py-3.5 shadow-[var(--ds-shadow-sm)] border border-[color-mix(in_oklab,var(--border)_50%,transparent)]">
            <div className="flex items-center justify-between">
              <span className="text-[length:var(--font-size-label)] font-bold">卡片圆角</span>
              <span className="tnum text-[11px] font-bold text-primary">
                {Math.round(theme.radius * 100)}%
              </span>
            </div>
            <input
              type="range"
              min={0}
              max={170}
              step={5}
              value={Math.round(theme.radius * 100)}
              onChange={(e) => patch({ radius: Number(e.target.value) / 100 })}
              className="theme-slider mt-2.5 w-full"
              aria-label="圆角"
            />
          </div>

          <div className="rounded-[var(--radius-lg)] bg-card px-4 py-3.5 shadow-[var(--ds-shadow-sm)] border border-[color-mix(in_oklab,var(--border)_50%,transparent)]">
            <div className="flex items-center justify-between">
              <span className="text-[length:var(--font-size-label)] font-bold">字号大小</span>
              <span className="tnum text-[11px] font-bold text-primary">
                {Math.round(theme.fontScale * 100)}%
              </span>
            </div>
            <input
              type="range"
              min={90}
              max={115}
              step={1}
              value={Math.round(theme.fontScale * 100)}
              onChange={(e) => patch({ fontScale: Number(e.target.value) / 100 })}
              className="theme-slider mt-2.5 w-full"
              aria-label="字号"
            />
            <p className="mt-2 text-[10px] text-muted-foreground">
              觉得字小可以调大，最高 115%
            </p>
          </div>
        </div>
      </section>

      {/* ── 恢复默认 ── */}
      <section className="px-5 pt-5">
        <button
          onClick={reset}
          className="press flex w-full items-center justify-center gap-1.5 rounded-[14px] bg-card py-3 text-[length:var(--font-size-small)] font-bold shadow-[var(--ds-shadow-sm)] border border-[color-mix(in_oklab,var(--border)_50%,transparent)] hover:text-primary"
        >
          <RotateCcw size={14} strokeWidth={2.6} /> 恢复默认外观
        </button>
        <p className="mt-3 flex items-center justify-center gap-1 text-[10px] text-muted-foreground">
          <Palette size={11} strokeWidth={2.6} />
          当前：{PRESETS.find((p) => p.hue === theme.hue)?.name ?? '自定义'} ·{' '}
          {theme.mode === 'auto' ? '跟随系统' : theme.mode === 'dark' ? '深色' : '浅色'}
        </p>
      </section>

      <div className="h-4" />

      <TabBar />
    </div>
  );
}
