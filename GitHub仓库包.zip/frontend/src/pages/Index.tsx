import { useMemo } from 'react';
import { useNavigate } from 'react-router-dom';
import { motion } from 'framer-motion';
import {
  BellRing,
  CheckCircle2,
  Flame,
  Wallet,
  ListTodo,
  Layers,
  BookOpen,
  Lightbulb,
  Boxes,
  NotebookPen,
  ArrowRight,
  CalendarClock,
} from 'lucide-react';
import {
  HeroClock,
  StatCard,
  QuickGrid,
  TodayPeek,
  type QuickItem,
} from '@/components/workspace/HomeWidgets';
import { SectionTitle } from '@/components/workspace/UI';
import { TabBar } from '@/components/workspace/TabBar';
import { useTodos, useReminders, useHabits, useLedger, useStorage } from '@/hooks/useWorkspace';
import { computeStats, weekMatrix } from '@/lib/stats';
import { todayKey, weekDays, formatMoney } from '@/lib/date';

const TEAL = 'var(--theme-green)';
const BLUE = 'var(--theme-blue)';
const GOLD = 'var(--theme-gold)';
const CORAL = 'var(--primary)';
const WEEK_SHORT = ['一', '二', '三', '四', '五', '六', '日'];

export default function Index() {
  const nav = useNavigate();
  const { todos } = useTodos();
  const { reminders } = useReminders();
  const { habits } = useHabits();
  const { entries } = useLedger();
  const { items } = useStorage();

  const stats = useMemo(
    () => computeStats(todos, reminders, habits, entries, items),
    [todos, reminders, habits, entries, items]
  );
  const matrix = useMemo(() => weekMatrix(habits), [habits]);
  const today = todayKey();
  const days = weekDays();

  const quickItems: QuickItem[] = [
    {
      path: '/reminders',
      label: '事项提醒',
      desc: '分类提醒',
      icon: <BellRing size={18} strokeWidth={2.4} />,
      color: CORAL,
      badge: stats.reminderCount ? String(stats.reminderCount) : undefined,
    },
    {
      path: '/todos',
      label: '待办清单',
      desc: '今日任务',
      icon: <ListTodo size={18} strokeWidth={2.4} />,
      color: BLUE,
      badge: stats.pendingCount ? String(stats.pendingCount) : undefined,
    },
    {
      path: '/habits',
      label: '习惯打卡',
      desc: '每日坚持',
      icon: <Flame size={18} strokeWidth={2.4} />,
      color: GOLD,
    },
    {
      path: '/ledger',
      label: '记账本',
      desc: '收支明细',
      icon: <Wallet size={18} strokeWidth={2.4} />,
      color: TEAL,
    },
    {
      path: '/storage',
      label: '储物清单',
      desc: '东西在哪',
      icon: <Boxes size={18} strokeWidth={2.4} />,
      color: 'oklch(0.66 0.11 200)',
    },
    {
      path: '/ideas',
      label: '灵感库',
      desc: '随手记录',
      icon: <Lightbulb size={18} strokeWidth={2.4} />,
      color: 'oklch(0.72 0.14 85)',
    },
    {
      path: '/review',
      label: '周度复盘',
      desc: '每周总结',
      icon: <NotebookPen size={18} strokeWidth={2.4} />,
      color: 'oklch(0.64 0.13 300)',
    },
    {
      path: '/more',
      label: '全部功能',
      desc: '更多',
      icon: <Layers size={18} strokeWidth={2.4} />,
      color: 'oklch(0.6 0.02 60)',
    },
  ];

  return (
    <div className="phone-shell safe-bottom">
      <HeroClock stats={stats} />

      {/* 统计卡片 */}
      <section className="px-5 pt-5">
        <SectionTitle>数据概览</SectionTitle>
        <div
          className="gap-2.5"
          style={{ display: 'grid', gridTemplateColumns: 'repeat(2, minmax(0, 1fr))' }}
        >
          <StatCard
            label="事项提醒"
            value={String(stats.reminderCount)}
            unit="件"
            hint={stats.reminderOverdue ? `${stats.reminderOverdue} 件已过期` : '今日无逾期'}
            color={CORAL}
            icon={<BellRing size={15} strokeWidth={2.6} />}
            onClick={() => nav('/reminders')}
            delay={0.02}
          />
          <StatCard
            label="本月已完成待办"
            value={String(stats.doneThisMonth)}
            unit="项"
            hint={stats.todayTodos ? `今天还有 ${stats.todayTodos} 项` : '保持这个节奏'}
            color={BLUE}
            icon={<CheckCircle2 size={15} strokeWidth={2.6} />}
            onClick={() => nav('/todos')}
            delay={0.06}
          />
          <StatCard
            label="连续打卡天数"
            value={String(stats.streak)}
            unit="天"
            hint={`今日 ${stats.todayHabitsDone}/${stats.habitTotal} 已完成`}
            color={GOLD}
            icon={<Flame size={15} strokeWidth={2.6} />}
            onClick={() => nav('/habits')}
            delay={0.1}
          />
          <StatCard
            label="本月支出汇总"
            value={'¥' + formatMoney(stats.monthExpense)}
            hint={
              stats.monthExpenseDelta
                ? `较上月${stats.monthExpenseDelta > 0 ? '多花' : '省'} ${Math.abs(
                    Math.round(stats.monthExpenseDelta)
                  )}%`
                : '本月刚开始'
            }
            trend={stats.monthExpenseDelta}
            color={TEAL}
            icon={<Wallet size={15} strokeWidth={2.6} />}
            onClick={() => nav('/ledger')}
            delay={0.14}
          />
          <div style={{ gridColumn: '1 / -1' }}>
            <StatCard
              label="待处理事项"
              value={String(stats.pendingCount)}
              unit="项待处理"
              hint={`待办 ${todos.filter((t) => !t.done).length} · 提醒 ${stats.reminderCount} · 借出 ${
                items.filter((i) => i.lentTo).length
              }`}
              color={CORAL}
              icon={<CalendarClock size={15} strokeWidth={2.6} />}
              onClick={() => nav('/todos')}
              wide
              delay={0.18}
            />
          </div>
        </div>
      </section>

      {/* 快捷跳转 */}
      <section className="px-5 pt-6">
        <SectionTitle hint="全部 →" onMore={() => nav('/more')}>
          快速跳转
        </SectionTitle>
        <QuickGrid items={quickItems} />
      </section>

      {/* 本周打卡概览 */}
      <section className="px-5 pt-6">
        <SectionTitle hint="去打卡 →" onMore={() => nav('/habits')}>
          本周打卡
        </SectionTitle>
        <div className="rounded-[var(--radius-lg)] border border-[color-mix(in_oklab,var(--border)_50%,transparent)] bg-card p-3.5 shadow-[var(--ds-shadow-sm)]">
          <div className="mb-2 flex justify-between pl-[68px] pr-[1px]">
            {days.map((d, i) => (
              <span
                key={d}
                className="w-6 text-center text-[9px] font-bold"
                style={{ color: d === today ? 'var(--primary)' : 'var(--muted-foreground)' }}
              >
                {WEEK_SHORT[i]}
              </span>
            ))}
          </div>
          <div className="space-y-1.5">
            {matrix.slice(0, 5).map(({ habit, cells }) => (
              <div key={habit.id} className="flex items-center gap-2">
                <span className="w-[62px] shrink-0 truncate text-[11px] font-bold text-foreground/80">
                  {habit.emoji} {habit.name}
                </span>
                {cells.map((on, i) => (
                  <div key={i} className="flex w-6 justify-center">
                    <motion.div
                      initial={false}
                      animate={{ scale: on ? 1 : 0.9 }}
                      className="size-[15px] rounded-[5px]"
                      style={{
                        background: on
                          ? habit.color
                          : days[i] > today
                            ? 'transparent'
                            : 'var(--secondary)',
                        opacity: days[i] > today ? 0.3 : 1,
                      }}
                    />
                  </div>
                ))}
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* 今天要做 */}
      <section className="px-5 pt-6">
        <SectionTitle hint="全部 →" onMore={() => nav('/todos')}>
          今天要做
        </SectionTitle>
        <TodayPeek />
      </section>

      {/* 复盘引导 */}
      <div className="px-5 pt-6 pb-2">
        <button
          onClick={() => nav('/review')}
          className="press flex w-full items-center justify-between rounded-[16px] p-4 text-left"
          style={{
            background:
              'linear-gradient(130deg, color-mix(in oklab, var(--primary) 12%, var(--card)), color-mix(in oklab, oklch(0.82 0.13 84) 16%, var(--card)))',
            border: '1px solid color-mix(in oklab, var(--primary) 16%, transparent)',
          }}
        >
          <div className="flex items-center gap-2.5">
            <span className="flex size-9 items-center justify-center rounded-[11px] bg-card/70 text-primary">
              <BookOpen size={17} strokeWidth={2.4} />
            </span>
            <div>
              <p className="text-[length:var(--font-size-label)] font-extrabold">写一写本周复盘</p>
              <p className="text-[10px] font-medium text-muted-foreground">
                回顾这 7 天，为下一周定个小目标
              </p>
            </div>
          </div>
          <ArrowRight size={16} className="shrink-0 text-primary" strokeWidth={2.8} />
        </button>
      </div>

      <TabBar />
    </div>
  );
}
