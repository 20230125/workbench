import { QueryClient, QueryClientProvider } from '@tanstack/react-query';
import { BrowserRouter, HashRouter, Route } from 'react-router-dom';
import { useEffect } from 'react';
import { Toaster } from "@/components/ui/sonner";
import { TooltipProvider } from "@/components/ui/tooltip";
import { AnimatedRoutes } from "@/components/AnimatedRoutes";
import { PageTransition } from "@/components/PageTransition";
import { store } from '@/lib/store';
import { todayKey } from '@/lib/date';
import { useTheme } from '@/hooks/useTheme';
import type { Meta } from '@/types/workspace';
import Index from "./pages/Index";
import Todos from './pages/Todos';
import Reminders from './pages/Reminders';
import Habits from './pages/Habits';
import Ledger from './pages/Ledger';
import Storage from './pages/Storage';
import Ideas from './pages/Ideas';
import Review from './pages/Review';
import More from './pages/More';
import Appearance from './pages/Appearance';
import NotFound from "./pages/NotFound";

const queryClient = new QueryClient({
  defaultOptions: {
    queries: {
      staleTime: 60 * 1000,
      gcTime: 5 * 60 * 1000,
      retry: 1,
      refetchOnWindowFocus: false,
      refetchOnReconnect: false,
    },
    mutations: { retry: 1 },
  },
});

/** 记录最后打开日期（用于跨天场景） */
function DailyReset() {
  useEffect(() => {
    const meta = store.read<Meta>('meta', { lastOpen: todayKey(), nickname: '我' });
    store.write('meta', { ...meta, lastOpen: todayKey() });
  }, []);
  return null;
}

/** 挂载主题：确保首屏就套用用户配色（并在切页时保持） */
function ThemeBoot() {
  useTheme();
  return null;
}

const ROUTES = [
  { path: '/', title: '今日 · 我的工作台', el: <Index />, key: 'Home', tr: 'fade' as const },
  { path: '/todos', title: '待办清单', el: <Todos />, key: 'Todos', tr: 'slide-fade' as const },
  { path: '/reminders', title: '事项提醒', el: <Reminders />, key: 'Reminders', tr: 'slide-fade' as const },
  { path: '/habits', title: '习惯打卡', el: <Habits />, key: 'Habits', tr: 'slide-fade' as const },
  { path: '/ledger', title: '记账本', el: <Ledger />, key: 'Ledger', tr: 'slide-fade' as const },
  { path: '/storage', title: '储物清单', el: <Storage />, key: 'Storage', tr: 'slide-fade' as const },
  { path: '/ideas', title: '灵感库', el: <Ideas />, key: 'Ideas', tr: 'slide-fade' as const },
  { path: '/review', title: '周度复盘', el: <Review />, key: 'Review', tr: 'slide-fade' as const },
  { path: '/more', title: '更多', el: <More />, key: 'More', tr: 'fade' as const },
  { path: '/appearance', title: '外观设置', el: <Appearance />, key: 'Appearance', tr: 'slide-fade' as const },
];

/** 路由 + 页面的公共部分，Router 由外层传入 */
function AppRoutes() {
  return (
    <AnimatedRoutes>
      {ROUTES.map((r) => (
        <Route
          key={r.key}
          path={r.path}
          data-genie-title={r.title}
          data-genie-key={r.key}
          element={<PageTransition transition={r.tr}>{r.el}</PageTransition>}
        />
      ))}
      <Route path="*" data-genie-key="NotFound" data-genie-title="Not Found" element={<PageTransition transition="fade"><NotFound /></PageTransition>} />
    </AnimatedRoutes>
  );
}

function AppShell({ hash }: { hash: boolean }) {
  const Router = hash ? HashRouter : BrowserRouter;
  return (
    <QueryClientProvider client={queryClient}>
      <TooltipProvider>
        <Toaster />
        <DailyReset />
        <ThemeBoot />
        <Router>
          <AppRoutes />
        </Router>
      </TooltipProvider>
    </QueryClientProvider>
  );
}

/** 单文件版（file://）与静态托管版都用 HashRouter，无需任何服务器路由配置 */
export function AppHash() {
  return <AppShell hash />;
}

/** 开发环境用 BrowserRouter，保持地址栏干净 */
export function AppForSingleFile() {
  return <AppHash />;
}

function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <TooltipProvider>
        <Toaster />
        <DailyReset />
        <ThemeBoot />
        <BrowserRouter>
          <AppRoutes />
        </BrowserRouter>
      </TooltipProvider>
    </QueryClientProvider>
  );
}

export default App
