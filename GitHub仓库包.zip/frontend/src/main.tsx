import {createRoot} from 'react-dom/client'
import './index.css'
import { AppHash } from './App.tsx'
import { registerServiceWorker } from './lib/pwa'

// 静态托管版使用 HashRouter：
// 1) 放到任意子目录都能跑（相对路径 + #/xxx）
// 2) 刷新 / 直接分享链接不会 404，无需配置服务器 rewrite 规则
createRoot(document.getElementById('root')!).render(<AppHash />)

// 注册 SW，让浏览器识别为「可安装 App」，桌面图标更完整
registerServiceWorker()
