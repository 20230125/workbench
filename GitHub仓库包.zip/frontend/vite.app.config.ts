import { defineConfig, type Plugin } from 'vite';
import react from '@vitejs/plugin-react-swc';
import tailwindcss from '@tailwindcss/vite';
import path from 'node:path';

/** 把构建出的入口 HTML 重命名为 index.html（Capacitor 强制要求） */
function renameEntry(): Plugin {
  return {
    name: 'rename-entry-html',
    enforce: 'post',
    generateBundle(_options, bundle) {
      for (const key of Object.keys(bundle)) {
        if (key.endsWith('.html') && key !== 'index.html') {
          const item = bundle[key];
          delete bundle[key];
          // @ts-expect-error 类型上 fileName 可写
          item.fileName = 'index.html';
          bundle['index.html'] = item;
        }
      }
    },
  };
}

/**
 * 原生 App（Capacitor）构建配置
 * 与网页版的区别：
 *  - base 必须为 './'，因为原生壳内资源通过本地文件协议加载
 *  - 不做代码分割，保证资源路径简单可靠
 */
export default defineConfig({
  plugins: [react(), tailwindcss(), renameEntry()],
  base: './',
  resolve: {
    alias: { '@': path.resolve(__dirname, './src') },
  },
  build: {
    outDir: 'dist-app',
    emptyOutDir: true,
    rollupOptions: {
      input: path.resolve(__dirname, 'index.app.html'),
      output: {
        // Capacitor 要求入口必须是 index.html
        entryFileNames: 'assets/[name]-[hash].js',
        chunkFileNames: 'assets/[name]-[hash].js',
        assetFileNames: 'assets/[name]-[hash].[ext]',
      },
    },
  },
});
