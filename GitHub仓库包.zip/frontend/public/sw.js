/* 极简 Service Worker
 * 目的：让浏览器满足「可安装（installable）」条件，从而出现「安装应用 / 添加到主屏幕」入口。
 * 策略：不缓存 HTML（保证更新即时生效），仅做网络直通 + 离线兜底提示。
 * 说明：本应用数据全部在 localStorage，不依赖 SW 缓存，因此这里刻意保持最小化。
 */

const VERSION = 'wb-v1';

self.addEventListener('install', (event) => {
  // 立即接管，无需等待
  self.skipWaiting();
  event.waitUntil(Promise.resolve());
});

self.addEventListener('activate', (event) => {
  event.waitUntil(
    (async () => {
      const keys = await caches.keys();
      await Promise.all(keys.filter((k) => k !== VERSION).map((k) => caches.delete(k)));
      await self.clients.claim();
    })()
  );
});

self.addEventListener('fetch', (event) => {
  const req = event.request;
  // 只处理同源 GET
  if (req.method !== 'GET' || new URL(req.url).origin !== self.location.origin) return;
  // 直通网络：本应用不需要离线缓存 HTML，避免版本陈旧
  event.respondWith(
    fetch(req).catch(() =>
      new Response('', { status: 503, statusText: 'offline' })
    )
  );
});
